// Run: node --test tools/expression_viewer/test_packs.cjs
const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {decode} = require('./codec.js');
const root = path.resolve(__dirname,'../..');
const pack = path.join(root,'tools/expression_sources/puppy/puppy-eyes-v2');
const json = file => JSON.parse(fs.readFileSync(file));
const definitions = json(path.join(pack,'animations.json'));
const candidate = json(path.join(pack,'240_240/emote.json'));
const original = json(path.join(root,'main/boards/puppy/240_240/emote.json'));

test('all 32 original resources/configurations remain byte-identical',()=>{
  for(const [name,expected] of Object.entries(json(path.join(pack,'original-hashes.json')))) {
    const actual=crypto.createHash('sha256').update(fs.readFileSync(path.join(root,name))).digest('hex');
    assert.equal(actual,expected,name);
  }
});

test('candidate changes exactly 21 feelings; all system entries and names are unchanged',()=>{
  assert.equal(Object.keys(definitions).length,21);
  assert.deepEqual(candidate.map(e=>e.emote),original.map(e=>e.emote));
  let changed=0;
  for(let i=0;i<original.length;i++) {
    const name=original[i].emote;
    if(definitions[name]) {
      changed++;assert.equal(candidate[i].src,`puppy-eyes-v2-${name}.eaf`);
      assert.equal(candidate[i].fps,30);assert.equal(candidate[i].loop,true);
      assert.ok(Buffer.byteLength(candidate[i].src)<32);
    } else assert.deepEqual(candidate[i],original[i],name);
  }
  assert.equal(changed,21);
  assert.equal(fs.readdirSync(path.join(pack,'emoji')).length,21);
});

test('every candidate decodes fully with correct timing, masked-circle margins, pauses and smooth seams',()=>{
  const signatures=new Set();
  for(const [name,definition] of Object.entries(definitions)) {
    const bytes=fs.readFileSync(path.join(pack,'emoji',`puppy-eyes-v2-${name}.eaf`));
    const result=decode(bytes);
    assert.equal(result.frames.length,Math.round(definition.seconds*definition.fps),name);
    assert.equal(result.width,240);assert.equal(result.height,240);
    assert.deepEqual(definition.keyframes[0].pose,definition.keyframes.at(-1).pose,name);
    let seam=0;
    for(let p=0;p<240*240;p++) if(result.frames[0][p*4]!==result.frames.at(-1)[p*4])seam++;
    assert.ok(seam<500,`${name}: seam changes ${seam} pixels`);
    const unique=new Set();
    for(const frame of result.frames) {
      unique.add(crypto.createHash('sha256').update(frame).digest('hex'));
      for(let p=0;p<240*240;p++) {
        assert.equal(frame[p*4+3],255,name);
        if(frame[p*4]||frame[p*4+1]||frame[p*4+2]) {
          const x=p%240-119.5,y=Math.floor(p/240)-119.5;
          assert.ok(x*x+y*y<110*110,`${name}: content violates circular safe area`);
        }
      }
    }
    assert.ok(unique.size>1,name+': must animate');
    assert.ok(unique.size<result.frames.length*.9,name+': must have holds');
    const index=Math.min(result.frames.length-1,Math.round(definition.representative*result.frames.length));
    signatures.add(crypto.createHash('sha256').update(result.frames[index]).digest('hex'));
  }
  // Abstract closed-eye gestures may be similar, but the complete set must
  // retain distinct representative poses, notably proud vs happy/laughing.
  assert.ok(signatures.size>=19);
});
