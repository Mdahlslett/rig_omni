#!/usr/bin/env python3
"""Validate the candidate with the existing packer in an isolated build directory."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]


def check():
    baseline = json.loads((HERE/"original-hashes.json").read_text())
    def originals_unchanged():
        for name,digest in baseline.items():
            assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == digest, name
    originals_unchanged()
    out = ROOT/"build/puppy-eyes-v2-check"
    for name in ["packer", "res", "config"]:
        (out/name).mkdir(parents=True,exist_ok=True)
    for script in (ROOT/"tools/spiffs_assets").glob("*.py"):
        shutil.copy2(script,out/"packer"/script.name)
    for entry in json.loads((HERE/"240_240/emote.json").read_text()):
        name = entry["src"]
        source = HERE/"emoji"/name if name.startswith("puppy-eyes-v2-") else ROOT/"main/boards/puppy/emoji"/name
        if name == "wificonfig.eaf":
            source = ROOT/"main/boards/puppy/emoji/wificonfig_domestic.eaf"
        shutil.copy2(source,out/"res"/name)
    shutil.copy2(HERE/"240_240/emote.json",out/"config/emote.json")
    shutil.copy2(ROOT/"main/boards/puppy/240_240/layout.json",out/"config/layout.json")
    font = ROOT/"tools/spiffs_assets/build/assets/font_puhui_common_20_4.bin"
    models = ROOT/"build/puppy/wakenet_staging"
    if not font.is_file() or not models.is_dir():
        raise SystemExit("Requires a previously built original Puppy assets package (font and wake-word staging). No active files were changed.")
    subprocess.run([sys.executable,str(out/"packer/build.py"),"--res_path",str(out/"res"),
        "--target_board",str(out/"config"),"--text_font",str(font),"--wakenet_model",str(models),
        "--assets_size","0x800000"],check=True)
    binary = (out/"packer/build/assets.bin").read_bytes()
    assert len(binary) <= 0x800000
    for path in (HERE/"emoji").glob("*.eaf"):
        assert path.read_bytes() in binary,path.name
    index = json.loads((out/"packer/build/assets/index.json").read_text())
    assert index["layout"] == json.loads((ROOT/"main/boards/puppy/240_240/layout.json").read_text())
    actual = {entry["name"]:entry for entry in index["emoji_collection"]}
    for entry in json.loads((HERE/"240_240/emote.json").read_text()):
        assert actual[entry["emote"]]["file"] == entry["src"]
        assert not actual[entry["emote"]].get("eaf",{}).get("lack",False)
    originals_unchanged()
    report = dict(candidate_assets_bytes=len(binary),partition_bytes=0x800000,
        remaining_bytes=0x800000-len(binary),region="domestic",all_21_candidates_present=True,
        originals_unchanged=True,hardware_tested=False)
    (HERE/"asset-check.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))


if __name__ == "__main__":
    check()
