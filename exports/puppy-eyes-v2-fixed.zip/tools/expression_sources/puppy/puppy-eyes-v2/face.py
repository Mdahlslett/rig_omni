"""One geometric, masked eye rig shared by every puppy-eyes-v2 emotion."""
import math
from PIL import Image, ImageChops, ImageDraw

DEFAULTS = dict(lift=0, dx=0, spread=0, tilt=0, gaze_x=0, gaze_y=0, pupil=32,
                top=0, top_l=0, top_r=0, bottom=0, smile=0, slope=0, converge=0,
                blink_l=0, blink_r=0, width_l=1, width_r=1, height_l=1, height_r=1)
WHITE = (248, 240, 224)
SCALE = 3


def pose_at(keyframes, t):
    """Smoothstep interpolation, with explicit holds between identical poses."""
    for left, right in zip(keyframes, keyframes[1:]):
        if t <= right["at"]:
            a = {**DEFAULTS, **left["pose"]}
            b = {**DEFAULTS, **right["pose"]}
            u = max(0, min(1, (t-left["at"])/(right["at"]-left["at"])))
            u = u*u*(3-2*u)
            return {key: a[key]+(b[key]-a[key])*u for key in DEFAULTS}
    return {**DEFAULTS, **keyframes[-1]["pose"]}


def render(pose):
    size = 240*SCALE
    face = Image.new("L", (size, size))
    for side, suffix, center in [(1, "l", 78), (-1, "r", 162)]:
        cx = (center+side*pose["spread"]+pose["dx"])*SCALE
        cy = (116-pose["lift"])*SCALE
        w, h = 58*pose["width_"+suffix]*SCALE, 76*pose["height_"+suffix]*SCALE
        blink = pose["blink_"+suffix]
        eye = Image.new("L", face.size)
        draw = ImageDraw.Draw(eye)
        draw.ellipse((cx-w/2, cy-h/2, cx+w/2, cy+h/2), fill=255)
        if blink >= .98:
            # A closed lid is a thin curved line, never a pupil or decoration.
            eye = Image.new("L", face.size)
            points = [(cx+w*(i/40-.5), cy+.05*h-8*SCALE*(1-(2*i/40-1)**2)) for i in range(41)]
            ImageDraw.Draw(eye).line(points, fill=255, width=3*SCALE, joint="curve")
            face = ImageChops.lighter(face, eye)
            continue
        top = max(0, min(1, pose["top"]+pose["top_"+suffix]+blink*.55))
        bottom = max(0, min(1, pose["bottom"]+blink*.45))
        # The lid polygons cut the eye and therefore all subsequent features.
        upper, lower = [], []
        for i in range(61):
            x = cx-w/2+w*i/60
            u = (x-cx)/(w/2)
            closing_curve = 8*SCALE*blink*(1-u*u)
            upper.append((x, cy-h/2+top*h+pose["slope"]*side*(x-cx)-closing_curve))
            lower.append((x, cy+h/2-bottom*h-pose["smile"]*h*(1-u*u)-closing_curve))
        draw.polygon([(cx-w/2, cy-h), (cx+w/2, cy-h)]+upper[::-1], fill=0)
        draw.polygon(lower+[(cx+w/2, cy+h), (cx-w/2, cy+h)], fill=0)
        pupil = Image.new("L", face.size)
        px, py = cx+(pose["gaze_x"]+side*pose["converge"])*SCALE, cy+pose["gaze_y"]*SCALE
        radius = pose["pupil"]*SCALE/2
        ImageDraw.Draw(pupil).ellipse((px-radius, py-radius, px+radius, py+radius), fill=255)
        pupil = ImageChops.multiply(pupil, eye)
        visible = ImageChops.subtract(eye, pupil)
        glint = Image.new("L", face.size)
        gx, gy, gr = px-5*SCALE, py-7*SCALE, 2.25*SCALE
        ImageDraw.Draw(glint).ellipse((gx-gr, gy-gr, gx+gr, gy+gr), fill=255)
        glint = ImageChops.multiply(glint, pupil)
        face = ImageChops.lighter(face, ImageChops.lighter(visible, glint))
    if pose["tilt"]:
        face = face.rotate(pose["tilt"], Image.Resampling.BICUBIC)
    face = face.resize((240,240), Image.Resampling.LANCZOS)
    # One fixed warm-white/black palette; intermediate colors are edge AA only.
    face = face.point([round(value*31/255) for value in range(256)])
    image = Image.new("P", (240,240))
    image.putdata(face.get_flattened_data())
    palette = [round(channel*level/31) for level in range(32) for channel in WHITE]
    image.putpalette(palette+[0]*(768-len(palette)))
    return image
