#!/usr/bin/env python3
"""Regenerate the separate candidate pack. Never activates or edits originals."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import zipfile

from PIL import Image
from face import DEFAULTS, pose_at, render

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path.insert(0, str(ROOT/"tools"))
from gif_to_eaf import encode_frames


def generate(names=None):
    definitions = json.loads((HERE/"animations.json").read_text())
    original = json.loads((ROOT/"main/boards/puppy/240_240/emote.json").read_text())
    for directory in ["emoji", "gif", "stills", "240_240"]:
        (HERE/directory).mkdir(exist_ok=True)
    rows = []
    for name, description in definitions.items():
        if names and name not in names:
            continue
        count = round(description["seconds"]*description["fps"])
        keys = description["keyframes"]
        assert keys[0]["at"] == 0 and keys[-1]["at"] == 1
        assert {**DEFAULTS, **keys[0]["pose"]} == {**DEFAULTS, **keys[-1]["pose"]}, name
        # Include the exact closing pose so rasterized lids do not snap at the
        # loop boundary. No extra end frames or pause blocks are appended.
        frames = [render(pose_at(keys, index/(count-1))) for index in range(count)]
        path = HERE/"emoji"/f"puppy-eyes-v2-{name}.eaf"
        encode_frames(frames, path, deduplicate=True)
        # GIFs are convenience sources, not the EAF timeline: GIF may merge holds.
        durations = [round((i+1)*100/description["fps"])*10-round(i*100/description["fps"])*10 for i in range(count)]
        frames[0].save(HERE/"gif"/f"{name}.gif", save_all=True, append_images=frames[1:],
                       duration=durations, loop=0, disposal=2, optimize=False)
        representative = min(count-1, round(description["representative"]*count))
        frames[representative].save(HERE/"stills"/f"{name}.png")
        base = ROOT/"main/boards/puppy/emoji"/f"{name}.eaf"
        rows.append(dict(name=name, frames=count, fps=description["fps"], seconds=count/description["fps"],
                         original_bytes=base.stat().st_size, candidate_bytes=path.stat().st_size,
                         sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
        print(name, count, "frames", path.stat().st_size, "bytes", flush=True)
    candidate = []
    for entry in original:
        if entry["emote"] in definitions:
            entry = {**entry, "src":f"puppy-eyes-v2-{entry['emote']}.eaf",
                     "fps":definitions[entry["emote"]]["fps"], "loop":True}
        candidate.append(entry)
    (HERE/"240_240/emote.json").write_text(json.dumps(candidate,ensure_ascii=False,indent=2)+"\n")
    if not names:
        (HERE/"report.json").write_text(json.dumps(dict(pack="puppy-eyes-v2", expressions=rows,
            original_total_bytes=sum(row["original_bytes"] for row in rows),
            candidate_total_bytes=sum(row["candidate_bytes"] for row in rows)),indent=2)+"\n")
        columns=5
        contact=Image.new("RGB",(columns*240,((len(rows)+columns-1)//columns)*270),(20,22,26))
        from PIL import ImageDraw
        draw=ImageDraw.Draw(contact)
        for i,row in enumerate(rows):
            x,y=(i%columns)*240,(i//columns)*270
            contact.paste(Image.open(HERE/"stills"/f"{row['name']}.png").convert("RGB"),(x,y))
            draw.text((x+12,y+244),row["name"],fill=(248,240,224))
        contact.save(HERE/"contact-sheet.png")


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--only", help="Comma-separated subset for visual development")
    args=parser.parse_args()
    generate(set(args.only.split(",")) if args.only else None)
