// End-to-end test of the actual ZIP after extraction, including no-JS use.
const {chromium}=require('playwright');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const {execFileSync}=require('node:child_process');
const assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..');
const archive=process.argv[2]||path.join(root,'build/puppy-viewer-ready.zip');
const extracted=fs.mkdtempSync(path.join(os.tmpdir(),'puppy-viewer-release-'));
execFileSync('python3',['-c','import sys,zipfile;zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])',archive,extracted]);

(async()=>{
  const browser=await chromium.launch({headless:true});
  try {
    const url='file://'+path.join(extracted,'START-HER.html');
    const noJs=await browser.newContext({javaScriptEnabled:false,offline:true,viewport:{width:1280,height:900}});
    const native=await noJs.newPage();
    await native.goto(url);
    assert.ok(await native.locator('.native-expression img').first().isVisible());
    let nativeCount=0;
    for(const pack of await native.locator('.native-pack').all()) {
      if(!await pack.evaluate(element=>element.open))await pack.locator(':scope > summary').click();
      for(const card of await pack.locator('.native-expression').all()) {
        if(!await card.evaluate(element=>element.open))await card.locator(':scope > summary').click();
        const image=card.locator('img');
        await image.evaluate(image=>image.decode());
        assert.deepEqual(await image.evaluate(image=>[image.naturalWidth,image.naturalHeight]),[240,240]);
        assert.ok(await image.isVisible());
        await card.locator(':scope > summary').click();nativeCount++;
      }
    }
    assert.equal(nativeCount,51);
    await native.screenshot({path:path.join(root,'build/puppy-native-no-js.png'),fullPage:true});
    const context=await browser.newContext({offline:true,viewport:{width:1360,height:1000}});
    const page=await context.newPage(),errors=[];
    page.on('pageerror',error=>errors.push(error.message));
    await page.goto(url);
    assert.ok(await page.locator('.native-expression img').first().isVisible());
    assert.equal(await page.locator('#advanced-player').evaluate(element=>element.open),false);
    await page.locator('#advanced-player > summary').click();
    await page.waitForFunction(()=>document.querySelector('#state').textContent==='Spiller');
    assert.equal(await page.locator('#pack').inputValue(),'original');
    const options=await page.locator('#expressions option').evaluateAll(options=>options.map(option=>({value:option.value,label:option.label})));
    let rendered=0;
    for(const pack of ['original','puppy-eyes-v2']) {
      await page.locator('#pack').selectOption(pack);
      for(const option of options) {
        await page.locator('#expressions').selectOption(option.value);
        await page.waitForFunction(label=>document.querySelector('#details').textContent.startsWith(label+' ·')&&!document.querySelector('#play').disabled,option.label);
        assert.equal(await page.locator('#error').isVisible(),false);
        assert.ok(await page.locator('#screen').evaluate(canvas=>canvas.getContext('2d').getImageData(0,0,240,240).data.some((value,index)=>index%4!==3&&value>0)));
        rendered++;
      }
    }
    await page.locator('#play').click();
    await page.locator('#timeline').evaluate(element=>{element.value=0;element.dispatchEvent(new Event('input'));});
    await page.locator('#next').click();assert.equal(await page.locator('#state').textContent(),'Pause');
    await page.locator('#restart').click();assert.equal(await page.locator('#state').textContent(),'Spiller');
    await page.locator('#seam').click();
    await page.locator('#advanced-player > summary').click();
    await page.waitForFunction(()=>document.querySelector('#state').textContent==='Pause');
    await page.locator('#static-gallery > summary').click();
    await page.setViewportSize({width:390,height:844});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
    assert.deepEqual(errors,[]);
    console.log(`PASS: actual extracted ZIP; ${nativeCount} GIF previews visible with JavaScript OFF; ${rendered} EAF selections rendered offline; advanced controls and mobile width; no page errors.`);
  } finally {await browser.close();fs.rmSync(extracted,{recursive:true,force:true});}
})().catch(error=>{console.error(error);process.exit(1);});
