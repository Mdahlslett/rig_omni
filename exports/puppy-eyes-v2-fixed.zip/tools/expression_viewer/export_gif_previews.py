#!/usr/bin/env python3
"""Export native-browser GIF previews from the actual EAF files (Pillow)."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys

from PIL import Image

TOOLS = Path(__file__).resolve().parent.parent
ROOT = TOOLS.parent
sys.path.insert(0,str(TOOLS))
from analyze_eaf import parse_file


def export_eaf(source, output, fps, loop):
    data, entries, parsed = parse_file(str(source))
    assert (sum(data[16:]) & 0xffffffff) == struct.unpack_from('<I',data,8)[0]
    frames, cache = [], {}
    for (size,offset),(_,_,info) in zip(entries,parsed):
        base=16+len(entries)*8+offset+2
        if data[base:base+3] == b'_C\0':
            continue
        key=(size,offset)
        if key in cache:
            frames.append(cache[key]); continue
        assert info.get('bit_depth')==8, source
        palette=base+18+info['blocks']*4
        cursor=palette+1024
        indices=bytearray()
        for block in range(info['blocks']):
            length=struct.unpack_from('<I',data,base+18+block*4)[0]
            end=cursor+length
            assert data[cursor]==0 and (length-1)%2==0
            cursor+=1
            while cursor<end:
                indices.extend(bytes([data[cursor+1]])*data[cursor]); cursor+=2
        assert len(indices)==info['width']*info['height']
        frame=Image.frombytes('P',(info['width'],info['height']),bytes(indices))
        rgb=[]
        for color in range(256):
            b,g,r,_=data[palette+color*4:palette+color*4+4]
            r5,g6,b5=r>>3,g>>2,b>>3
            rgb.extend(((r5<<3)|(r5>>2),(g6<<2)|(g6>>4),(b5<<3)|(b5>>2)))
        frame.putpalette(rgb)
        cache[key]=frame;frames.append(frame)
    durations=[round((i+1)*100/fps)*10-round(i*100/fps)*10 for i in range(len(frames))]
    output.parent.mkdir(parents=True,exist_ok=True)
    options={'loop':0} if loop else {}
    frames[0].save(output,save_all=True,append_images=frames[1:],duration=durations,
                   optimize=False,disposal=2,**options)
    return dict(source_sha256=hashlib.sha256(data).hexdigest(),frames=len(frames),fps=fps,
                duration_ms=sum(durations),gif=str(output.relative_to(output.parents[1])))


def export(output):
    records={}
    board=ROOT/'main/boards/puppy'
    pack=TOOLS/'expression_sources/puppy/puppy-eyes-v2'
    for entry in json.loads((board/'240_240/emote.json').read_text()):
        names=[f'wificonfig_{region}.eaf' for region in ['domestic','overseas']] if entry['emote']=='wificonfig' else [entry['src']]
        for name in names:
            key='original/'+name
            records[key]=export_eaf(board/'emoji'/name,output/'original'/Path(name).with_suffix('.gif'),entry['fps'],entry['loop'])
    if (pack/'240_240/emote.json').exists():
        for entry in json.loads((pack/'240_240/emote.json').read_text()):
            if not entry['src'].startswith('puppy-eyes-v2-'):continue
            key='puppy-eyes-v2/'+entry['src']
            records[key]=export_eaf(pack/'emoji'/entry['src'],output/'puppy-eyes-v2'/f"{entry['emote']}.gif",entry['fps'],entry['loop'])
    (output/'manifest.json').write_text(json.dumps(records,indent=2)+'\n')
    print(f'Exported {len(records)} EAF-derived GIF previews to {output}')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'build/expression-gif-previews')
    export(parser.parse_args().output)
