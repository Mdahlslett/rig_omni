// Run with: node --test tools/expression_viewer/test_codec.cjs
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { decode } = require('./codec.js');

test('browser decoder remains available when a host also defines CommonJS module', () => {
  const host = { module: { exports: {} } };
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, 'codec.js'), 'utf8'), host);
  assert.equal(typeof host.EafCodec.decode, 'function');
  assert.equal(host.EafCodec, host.module.exports);
});

function checksum(bytes) {
  let sum = 0;
  for (let i = 16; i < bytes.length; i++) sum = (sum + bytes[i]) >>> 0;
  bytes.writeUInt32LE(sum, 8);
  return bytes;
}

function sample() {
  const frame = Buffer.alloc(2 + 18 + 4 + 1024 + 5);
  frame.writeUInt16LE(0x5a5a);
  frame.write('_S\0', 2, 'ascii');
  frame[11] = 8;
  frame.writeUInt16LE(2, 12); // width
  frame.writeUInt16LE(1, 14); // height
  frame.writeUInt16LE(1, 16); // blocks
  frame.writeUInt16LE(1, 18); // block height
  frame.writeUInt32LE(5, 20);
  frame.set([0, 0, 255, 255], 24 + 4); // BGRA red
  frame.set([255, 0, 0, 255], 24 + 8); // BGRA blue
  frame.set([0, 1, 1, 1, 2], frame.length - 5); // RLE: one red, one blue
  const flag = Buffer.from([90, 90, 95, 67, 0]);
  const bytes = Buffer.alloc(32 + frame.length + flag.length);
  bytes.set([0x89, 69, 65, 70]);
  bytes.writeUInt32LE(2, 4);
  bytes.writeUInt32LE(bytes.length - 16, 12);
  bytes.writeUInt32LE(frame.length, 16);
  bytes.writeUInt32LE(flag.length, 24);
  bytes.writeUInt32LE(frame.length, 28);
  bytes.set(frame, 32); bytes.set(flag, 32 + frame.length);
  return { bytes: checksum(bytes), block: 32 + frame.length - 5 };
}

test('decodes palette colors and omits the control marker', () => {
  const result = decode(sample().bytes);
  assert.equal(result.width, 2); assert.equal(result.height, 1);
  assert.equal(result.frames.length, 1);
  assert.deepEqual([...result.frames[0]], [255, 0, 0, 255, 0, 0, 255, 255]);
});

test('preserves a transparent palette entry', () => {
  const { bytes, block } = sample(); bytes[block + 2] = 0;
  assert.deepEqual([...decode(checksum(bytes)).frames[0].slice(0, 4)], [0, 0, 0, 0]);
});

test('rejects truncated files, corrupted checksums and out-of-bounds entries', () => {
  assert.throws(() => decode(Buffer.alloc(4)), /kort/);
  const { bytes } = sample(); bytes[bytes.length - 1] ^= 1;
  assert.throws(() => decode(bytes), /kontrollsum/);
  const other = sample().bytes; other.writeUInt32LE(0xffffffff, 20);
  assert.throws(() => decode(checksum(other)), /utenfor/);
});

test('rejects RLE overflow, underfill and unsupported encodings', () => {
  for (const [change, expected] of [
    [(bytes, block) => { bytes[block + 1] = 3; }, /overskrider/],
    [(bytes, block) => { bytes[block + 1] = 0; }, /fyller ikke/],
    [(bytes, block) => { bytes[block] = 1; }, /RLE-koding/],
  ]) {
    const { bytes, block } = sample(); change(bytes, block);
    assert.throws(() => decode(checksum(bytes)), expected);
  }
});

test('decodes every original Puppy frame with valid dimensions and pixel buffers', () => {
  const root = path.resolve(__dirname, '../../main/boards/puppy/emoji');
  const files = fs.readdirSync(root).filter(file => file.endsWith('.eaf'));
  assert.ok(files.length >= 29);
  for (const file of files) {
    const bytes = fs.readFileSync(path.join(root, file));
    const result = decode(bytes);
    assert.equal(result.width, 240, file); assert.equal(result.height, 240, file);
    assert.equal(result.frames.length, bytes.readUInt32LE(4) - 1, file);
    for (const frame of result.frames) assert.equal(frame.length, 240 * 240 * 4, file);
  }
});

test('proud is registered and preserves all 30 looping animation frames', () => {
  const board = path.resolve(__dirname, '../../main/boards/puppy');
  const manifest = JSON.parse(fs.readFileSync(path.join(board, '240_240/emote.json')));
  const entry = manifest.find(item => item.emote === 'proud');
  assert.deepEqual(entry, { emote: 'proud', src: 'proud.eaf', loop: true, fps: 30 });
  const result = decode(fs.readFileSync(path.join(board, 'emoji', entry.src)));
  assert.equal(result.frames.length, 30);
  assert.deepEqual(result.frames[0], result.frames[29]);
  assert.notDeepEqual(result.frames[0], result.frames[14]);
});
