"""Validate every exported GIF pixel against the actual EAF decoder (Pillow/Node)."""
import json
from pathlib import Path
import subprocess
from PIL import Image

ROOT=Path(__file__).resolve().parents[2]
CACHE=ROOT/'build/expression-gif-previews'
NODE="""const fs=require('fs'),codec=require(process.argv[1]);
const d=codec.decode(fs.readFileSync(process.argv[2]));
process.stdout.write(Buffer.concat(d.frames.map(frame=>Buffer.from(frame))));"""


def check():
    manifest=json.loads((CACHE/'manifest.json').read_text())
    frames_checked=0
    for key,metadata in manifest.items():
        group,name=key.split('/')
        source=(ROOT/'main/boards/puppy/emoji'/name if group=='original' else
                ROOT/'tools/expression_sources/puppy/puppy-eyes-v2/emoji'/name)
        raw=subprocess.check_output(['node','-e',NODE,str(ROOT/'tools/expression_viewer/codec.js'),str(source)])
        count=metadata['frames'];stride=240*240*4
        assert len(raw)==count*stride,key
        with Image.open(CACHE/metadata['gif']) as image:
            encoded=[];durations=[]
            for index in range(image.n_frames):
                image.seek(index);encoded.append(image.convert('RGB').tobytes());durations.append(image.info['duration'])
            assert sum(durations)==metadata['duration_ms'],key
        frame_index=0;boundary=durations[0];time=0
        for index in range(count):
            while time>=boundary and frame_index+1<len(encoded):
                frame_index+=1;boundary+=durations[frame_index]
            expected=Image.frombytes('RGBA',(240,240),raw[index*stride:(index+1)*stride]).convert('RGB').tobytes()
            assert expected==encoded[frame_index],f'{key}, EAF frame {index}: GIF pixels differ'
            time=round((index+1)*100/metadata['fps'])*10
            frames_checked+=1
        print('GIF pixels and timing verified:',key,flush=True)
    print(f'PASS: {len(manifest)} GIFs, {frames_checked} EAF timeline frames; every pixel and duration verified.')


if __name__=='__main__':check()
