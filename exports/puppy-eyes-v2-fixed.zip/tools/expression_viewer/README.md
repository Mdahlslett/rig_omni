# Puppy expression viewer

For the robust portable release, export native GIFs from the actual EAF files,
then generate the small entry page and its companion files:

```sh
python3 tools/expression_viewer/export_gif_previews.py
python3 tools/preview_expressions.py --portable --output build/puppy-viewer-ready
```

The first command requires Pillow. Unzip `build/puppy-viewer-ready.zip` fully,
then open **START-HER.html**. Keep the JavaScript files and previews directory
beside it. Native GIF previews display without JavaScript or canvas. The
advanced EAF player is optional and loads only when opened. Original remains
the default; the candidate is not activated on the robot.

Do not open the source `tools/expression_viewer/index.html` as a local file or
open HTML inside an unextracted ZIP. Use the entry file at the extracted root.

Validation of this release:

```sh
python3 tools/expression_viewer/test_gif_previews.py
node tools/expression_viewer/check_portable.cjs
```

The second check requires Playwright/Chromium and tests the actual ZIP after
extraction, with JavaScript both disabled and enabled. The portable directory
also works on a static web server without a build step.

Generate an offline viewer from the original Puppy assets:

```sh
python3 tools/preview_expressions.py
```

Open `build/puppy-viewer.html` in a current browser. The file contains the player
and all registered EAF files, including both Wi-Fi regions and `proud`. It can be copied to another
computer and opened without Python, a server, or an Internet connection.
The generator also produces `build/puppy-viewer.zip`. If an embedded HTML preview
does not allow scripts, download the ZIP, extract it, and open `puppy-viewer.html`
in a normal browser.
The generated HTML also embeds static first-frame previews of all registered assets.
These remain visible when JavaScript is disabled or blocked; successful player
startup hides the fallback gallery.
To open the new animation directly, append `#proud` to the HTML file URL.

When `tools/expression_sources/puppy/puppy-eyes-v2/` is available, the same
viewer includes the 21 alternative EAF candidates. Original remains the default.
Choose the pack and compare the same feeling side-by-side, with each file's own
duration. Both sides show decoded EAF data. Restart and loop-boundary controls,
frame counts, FPS, durations and file sizes support quality checks. Candidate
static fallbacks show representative decoded frames. Nothing in the viewer
activates a firmware pack or modifies the board configuration.

`tools/expression_viewer/index.html` also works when served from the repository
by a static HTTP server: it loads the original manifest and EAF files from
`main/boards/puppy/`. Keep that directory available at its repository-relative
path. Opening this source page directly with `file://` shows instructions for
generating the offline file instead of an empty viewer.

The viewer offers expression search, playback/pause, frame stepping/scrubbing,
FPS and loop controls, a circular screen mask, zoom, and PNG frame export.
Playback defaults come from `main/boards/puppy/240_240/emote.json`.

To choose another output path:

```sh
python3 tools/preview_expressions.py --output /tmp/puppy-viewer.html
```

The decoder reuses the EAF layout documented in `tools/analyze_eaf.py` and the
RLE/palette behavior in the installed `esp_emote_gfx` component. It validates
checksums and frame/block bounds, skips `_C` control markers, and supports the
8-bit, RLE-encoded frames used by the current Puppy assets. Other encodings
produce an error rather than a misleading preview. Colors are reduced to RGB565
as in the firmware, then expanded for the browser canvas.

This is an asset preview, not a firmware emulator: it does not run application
events, motor actions, overlays, or hardware display orientation. PNG export
captures the square frame; the circular mask is only a viewing aid. Browser
timing may differ from the device. Regenerate the HTML after changing assets or
their configuration. No firmware, original asset, or package dependency changes
are required.

Decoder checks (requires Node.js, not needed to use or generate the viewer):

```sh
node --test tools/expression_viewer/test_codec.cjs
```
