// Optional browser QA: requires Playwright and an installed Chromium browser.
// Run from the project root after python3 tools/preview_expressions.py.
const {chromium}=require('playwright');
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..');
const definitions=JSON.parse(fs.readFileSync(path.join(root,'tools/expression_sources/puppy/puppy-eyes-v2/animations.json')));
const out=path.join(root,'build/puppy-eyes-v2-visual');
fs.mkdirSync(out,{recursive:true});
(async()=>{
  const browser=await chromium.launch({headless:true});
  try {
    const context=await browser.newContext({offline:true,viewport:{width:1360,height:1000}});
    const page=await context.newPage(),errors=[];
    page.on('pageerror',error=>errors.push(error.message));
    const url='file://'+path.join(root,'build/puppy-viewer.html');
    await page.goto(url);
    await page.waitForFunction(()=>document.querySelector('#state').textContent==='Spiller');
    assert.equal(await page.locator('#pack').inputValue(),'original');
    await page.locator('#pack').selectOption('puppy-eyes-v2');
    for(const [name,definition]of Object.entries(definitions)) {
      await page.locator('#expressions').selectOption({label:name});
      await page.waitForFunction(name=>document.querySelector('#details').textContent.includes(`puppy-eyes-v2-${name}.eaf`)&&!document.querySelector('#play').disabled,name);
      if(await page.locator('#play').textContent()==='Pause')await page.locator('#play').click();
      assert.equal(await page.locator('#fps').inputValue(),'30');
      assert.ok((await page.locator('#details').textContent()).includes(`${Math.round(definition.seconds*30)} rammer`));
      await page.evaluate(name=>{
        const item=JSON.parse(document.querySelector('#expression-data').textContent).find(item=>item.name===name);
        window.__qaExpected=EafCodec.decode(Uint8Array.from(atob(item.alternatives['puppy-eyes-v2'].data),c=>c.charCodeAt(0)));
      },name);
      for(const [sample,t]of [0,.2,.4,.6,.8,1].entries()) {
        const index=Math.round(t*(definition.seconds*30-1));
        await page.locator('#timeline').evaluate((element,index)=>{element.value=index;element.dispatchEvent(new Event('input'));},index);
        assert.ok(await page.evaluate(index=>{
          const canvas=document.querySelector('#screen');
          const actual=canvas.getContext('2d').getImageData(0,0,240,240).data;
          return actual.every((value,pixel)=>value===window.__qaExpected.frames[index][pixel]);
        },index),`${name} frame ${index}: viewer pixels differ from EAF`);
        const data=await page.locator('#screen').evaluate(canvas=>canvas.toDataURL('image/png').split(',')[1]);
        fs.writeFileSync(path.join(out,`${name}-${sample}.png`),Buffer.from(data,'base64'));
      }
      await page.locator('#timeline').evaluate((element,index)=>{element.value=index;element.dispatchEvent(new Event('input'));},Math.round(definition.representative*(definition.seconds*30-1)));
      await page.locator('#compare').uncheck();await page.locator('#zoom').selectOption('2');
      const enlarged=await page.locator('#screen').boundingBox();
      assert.equal(enlarged.width,480);assert.equal(enlarged.height,480);
      await page.locator('#screen').screenshot({path:path.join(out,`${name}-2x.png`)});
      await page.locator('#zoom').selectOption('1');await page.locator('#compare').check();
      console.log('Rendered decoded EAF:',name);
    }
    await page.locator('#expressions').selectOption({label:'proud'});
    await page.waitForFunction(()=>document.querySelector('#details').textContent.includes('puppy-eyes-v2-proud.eaf')&&!document.querySelector('#play').disabled);
    await page.locator('#play').click();
    await page.locator('#timeline').evaluate(element=>{element.value='50';element.dispatchEvent(new Event('input'));});
    await page.screenshot({path:path.join(out,'comparison-1x.png'),fullPage:true});
    let box=await page.locator('#screen').boundingBox();assert.equal(box.width,240);assert.equal(box.height,240);
    await page.locator('#compare').uncheck();await page.locator('#zoom').selectOption('2');
    box=await page.locator('#screen').boundingBox();assert.equal(box.width,480);assert.equal(box.height,480);
    await page.screenshot({path:path.join(out,'comparison-2x.png'),fullPage:true});
    await page.locator('#round').uncheck();assert.ok(!(await page.locator('#screen').getAttribute('class')).includes('round'));
    await page.locator('#restart').click();assert.equal(await page.locator('#state').textContent(),'Spiller');
    await page.locator('#seam').click();await page.waitForTimeout(450);assert.equal(await page.locator('#state').textContent(),'Spiller');
    await page.locator('#next').click();assert.equal(await page.locator('#state').textContent(),'Pause');
    await page.locator('#expressions').selectOption({label:'nvs_reset'});
    await page.waitForFunction(()=>document.querySelector('#details').textContent.includes('nvs_reset.eaf')&&!document.querySelector('#play').disabled);
    assert.ok((await page.locator('#compare-label').textContent()).includes('uendret'));
    assert.equal(await page.locator('#fps').inputValue(),'5');
    await page.waitForFunction(()=>document.querySelector('#state').textContent==='Ferdig',{},{timeout:5000});
    await page.setViewportSize({width:390,height:844});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
    assert.deepEqual(errors,[]);
    const fallback=await browser.newContext({javaScriptEnabled:false,offline:true});
    const staticPage=await fallback.newPage();await staticPage.goto(url);
    assert.equal(await staticPage.locator('#static-gallery img').count(),51);
    const result={candidate_expressions_rendered:21,decoded_samples:126,original_default:true,
      exact_1x_and_2x:true,controls_verified:true,errors};
    fs.writeFileSync(path.join(out,'result.json'),JSON.stringify(result,null,2));
    console.log('PASS:',JSON.stringify(result));
  } finally {await browser.close();}
})().catch(error=>{console.error(error);process.exit(1);});
