(async function () {
  "use strict";
  const items = globalThis.PUPPY_EXPRESSIONS || JSON.parse(document.getElementById("expression-data").textContent);
  // The source page works on a static server too; generated HTML embeds these
  // assets and never fetches them. Keep original resources read-only.
  if (!items.length) {
    if (location.protocol === "file:") {
      throw new Error("Dette er kildeversjonen. Kjør python3 tools/preview_expressions.py fra prosjektmappen og åpne build/puppy-viewer.html, eller pakk ut den nedlastede ZIP-filen og åpne puppy-viewer.html.");
    }
    const root = new URL("../../main/boards/puppy/", document.baseURI);
    const response = await fetch(new URL("240_240/emote.json", root));
    if (!response.ok) throw new Error(`Kunne ikke laste uttrykkslisten (HTTP ${response.status}). Nettsiden må ha tilgang til prosjektets main/boards/puppy-mappe.`);
    const manifest = await response.json();
    for (const expression of manifest) {
      const regions = expression.emote === "wificonfig" ? ["domestic", "overseas"] : [null];
      for (const region of regions) {
        const file = region ? `wificonfig_${region}.eaf` : expression.src;
        items.push({name: expression.emote, region, file, fps: expression.fps, loop: expression.loop,
          url: new URL(`emoji/${file}`, root).href});
      }
    }
    const packRoot = new URL("../expression_sources/puppy/puppy-eyes-v2/", document.baseURI);
    const optional = await fetch(new URL("240_240/emote.json", packRoot));
    if (optional.ok) {
      const candidates = await optional.json();
      for (const item of items) {
        const candidate = candidates.find(entry => entry.emote === item.name && entry.src.startsWith("puppy-eyes-v2-"));
        if (candidate) item.alternatives = {"puppy-eyes-v2": {file: candidate.src, fps: candidate.fps, loop: candidate.loop,
          url: new URL(`emoji/${candidate.src}`, packRoot).href}};
      }
    }
  }
  if (!items.length) throw new Error("Uttrykkslisten er tom.");
  const $ = id => document.getElementById(id);
  const canvas = $("screen"), context = canvas.getContext("2d");
  const compareCanvas = $("compare-screen"), compareContext = compareCanvas.getContext("2d");
  $("pack").querySelector('[value="puppy-eyes-v2"]').disabled = !items.some(item => item.alternatives);
  let comparison = null, comparisonEntry = null, elapsed = 0;
  let selected = 0, decoded = null, frame = 0, playing = false, lastTime = null, request = null, playbackFps = 30, selectionVersion = 0;
  const requested = new URLSearchParams(location.search).get("expression") || location.hash.slice(1);
  const requestedIndex = items.findIndex(item => item.name === requested);
  if (requestedIndex >= 0) selected = requestedIndex;
  const controls = ["play", "restart", "previous", "next", "timeline", "fps", "loop", "reset", "export", "seam"];
  const variant = pack => pack === "original" ? items[selected] : items[selected].alternatives?.[pack] || items[selected];
  const otherPack = () => $("pack").value === "original" ? "puppy-eyes-v2" : "original";
  const packName = pack => pack === "original" ? "Original" : pack;
  async function load(entry) {
    let bytes;
    if (entry.data) bytes = Uint8Array.from(atob(entry.data), char => char.charCodeAt(0));
    else {
      const response = await fetch(entry.url);
      if (!response.ok) throw new Error(`Kunne ikke laste ${entry.file} (HTTP ${response.status}).`);
      bytes = new Uint8Array(await response.arrayBuffer());
    }
    return {...EafCodec.decode(bytes), bytes:bytes.length};
  }
  const details = (asset, entry) => `${entry.file} · ${asset.width} × ${asset.height} · ${asset.frames.length} rammer · ${entry.fps} FPS · ${(asset.frames.length/entry.fps).toFixed(2)} s · ${(asset.bytes/1024).toFixed(1)} KiB`;

  function label(item) {
    return item.name + (item.region ? ` · ${item.region === "domestic" ? "Kina" : "Internasjonal"}` : "");
  }
  function render() {
    if (!decoded) return;
    context.fillStyle = "#000";
    context.fillRect(0, 0, canvas.width, canvas.height);
    // Composite transparent palette entries onto the same black background.
    const image = new ImageData(decoded.frames[frame], decoded.width, decoded.height);
    const staging = document.createElement("canvas");
    staging.width = decoded.width; staging.height = decoded.height;
    staging.getContext("2d").putImageData(image, 0, 0);
    context.drawImage(staging, 0, 0);
    if (comparison) {
      let index = Math.floor(elapsed*comparisonEntry.fps/1000);
      index = comparisonEntry.loop ? index % comparison.frames.length : Math.min(index, comparison.frames.length-1);
      staging.getContext("2d").putImageData(new ImageData(comparison.frames[index],comparison.width,comparison.height),0,0);
      compareContext.fillStyle = "#000"; compareContext.fillRect(0,0,240,240); compareContext.drawImage(staging,0,0);
    }
    $("timeline").value = frame;
    $("frame").textContent = `${frame + 1} / ${decoded.frames.length}`;
  }
  function pause(message = "Pause") {
    playing = false; lastTime = null;
    if (request !== null) cancelAnimationFrame(request);
    request = null;
    $("play").textContent = "Spill av";
    $("state").textContent = message;
  }
  function tick(time) {
    if (!playing) return;
    if (lastTime === null) lastTime = time;
    const interval = 1000 / playbackFps;
    const steps = Math.floor((time - lastTime) / interval);
    if (steps > 0) {
      lastTime += steps * interval;
      elapsed += steps * interval;
      const next = frame + steps;
      if (!$("loop").checked && next >= decoded.frames.length) {
        frame = decoded.frames.length - 1; render(); pause("Ferdig"); return;
      }
      frame = next % decoded.frames.length; render();
    }
    request = requestAnimationFrame(tick);
  }
  function play() {
    if (!decoded || playing) return;
    if (!$("loop").checked && frame === decoded.frames.length - 1) { frame = 0; elapsed = 0; render(); }
    playing = true; lastTime = null;
    $("play").textContent = "Pause"; $("state").textContent = "Spiller";
    request = requestAnimationFrame(tick);
  }
  function defaults() {
    playbackFps = variant($("pack").value).fps;
    $("fps").value = playbackFps; $("loop").checked = variant($("pack").value).loop; lastTime = null;
  }
  async function select(index) {
    const version = ++selectionVersion;
    pause(); decoded = null; comparison = null; selected = index; frame = 0; elapsed = 0;
    $("error").hidden = true;
    controls.forEach(id => { $(id).disabled = true; });
    try {
      $("state").textContent = "Laster uttrykk …";
      const entry = variant($("pack").value), otherEntry = variant(otherPack());
      const [chosen,other] = await Promise.all([load(entry),load(otherEntry)]);
      if (version !== selectionVersion) return;
      decoded = chosen; comparison = other; comparisonEntry = otherEntry;
      canvas.width = decoded.width; canvas.height = decoded.height;
      $("timeline").max = decoded.frames.length - 1;
      $("details").textContent = `${label(items[index])} · ${details(decoded,entry)}`;
      $("compare-details").textContent = details(comparison,otherEntry);
      $("pack-label").textContent = packName($("pack").value);
      $("compare-label").textContent = packName(otherPack())+(!items[index].alternatives ? " · systemuttrykk uendret" : "");
      controls.forEach(id => { $(id).disabled = false; });
      defaults(); render();
      if ($("advanced-player") && !$("advanced-player").open) pause("Klar"); else play();
      $("loading").hidden = true;
      const gallery = $("static-gallery");
      if (gallery) gallery.open = false;
    } catch (error) {
      if (version !== selectionVersion) return;
      context.clearRect(0, 0, canvas.width, canvas.height);
      $("details").textContent = items[index].file;
      $("error").textContent = error.message; $("error").hidden = false;
      $("state").textContent = "Kan ikke åpne uttrykket";
      $("loading").hidden = true;
    }
  }
  function filter() {
    const query = $("search").value.trim().toLowerCase();
    const options = items.flatMap((item, index) => {
      if (!label(item).toLowerCase().includes(query)) return [];
      const option = new Option(label(item), String(index));
      option.selected = selected === index; return [option];
    });
    $("expressions").replaceChildren(...options);
    $("empty").hidden = options.length > 0;
    if (options.length && !options.some(option => Number(option.value) === selected)) {
      $("expressions").value = options[0].value; select(Number(options[0].value));
    }
  }
  $("search").addEventListener("input", filter);
  $("expressions").addEventListener("change", event => select(Number(event.target.value)));
  $("pack").addEventListener("change", () => select(selected));
  $("compare").addEventListener("change", () => {
    $("comparison").hidden = !$("compare").checked; $("screens").classList.toggle("single",!$("compare").checked);
  });
  $("play").addEventListener("click", () => playing ? pause() : play());
  function seek(index) { if (decoded) { pause(); frame = Math.max(0, Math.min(index, decoded.frames.length - 1)); elapsed = frame/playbackFps*1000; render(); } }
  $("restart").addEventListener("click", () => { seek(0); play(); });
  $("seam").addEventListener("click", () => { seek(decoded.frames.length-8); $("loop").checked=true; play(); });
  $("previous").addEventListener("click", () => seek(frame - 1));
  $("next").addEventListener("click", () => seek(frame + 1));
  $("timeline").addEventListener("input", event => seek(Number(event.target.value)));
  $("fps").addEventListener("change", () => {
    const value = Number($("fps").value);
    $("fps").value = Number.isFinite(value) && value >= 1 ? Math.min(120, Math.round(value)) : variant($("pack").value).fps;
    playbackFps = Number($("fps").value);
    lastTime = null;
  });
  $("reset").addEventListener("click", defaults);
  $("round").addEventListener("change", () => {
    for (const element of [canvas,compareCanvas]) element.classList.toggle("round",$("round").checked);
  });
  $("zoom").addEventListener("change", () => {
    const scale = Number($("zoom").value);
    for (const element of [canvas,compareCanvas]) element.style.width = `${240*scale}px`;
  });
  $("export").addEventListener("click", () => {
    const link = document.createElement("a");
    link.download = `${variant($("pack").value).file.replace(/\.eaf$/, "")}-${frame + 1}.png`;
    link.href = canvas.toDataURL("image/png"); link.click();
  });
  document.addEventListener("visibilitychange", () => { if (document.hidden && playing) pause(); });
  filter();
  const advanced = $("advanced-player");
  if (advanced) {
    controls.forEach(id => { $(id).disabled = true; });
    $("loading").hidden = true;
    advanced.addEventListener("toggle", () => {
      if (!advanced.open) pause();
      else if (!decoded) select(selected);
      else play();
    });
  } else await select(selected);
})().catch(error => {
  document.getElementById("loading").hidden = true;
  const message = document.getElementById("error");
  message.textContent = error.message; message.hidden = false;
  document.getElementById("state").textContent = "Uttrykkene kunne ikke lastes";
  document.querySelectorAll("button, input, select").forEach(control => { control.disabled = true; });
});
