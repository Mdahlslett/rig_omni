# Utførte kontroller

- 21 kandidater i 240×240, 8-bits RLE, 30 FPS. Alle EAF-rammer og kontrollsummer dekodes.
- 9 automatiske dekoder-/pakketester bestod. 32 originalfiler og aktiv konfigurasjon/layout er byteidentiske med før arbeidet.
- Alle 21 GIF-er har riktig dimensjon og total varighet. Opprinnelig GIF→EAF-konvertering er kontrollert byte for byte etter gjenbruk av koderen.
- Kandidatmanifestet endrer nøyaktig 21 følelsesreferanser. System- og statusoppføringer er uendret.
- Alle 21 følelser ble vist i Chromium fra faktiske EAF-filer. 126 tidslinjebilder ble pikselkontrollert mot EAF-dekoderen og visuelt gjennomgått som bevegelsesark.
- Kontroller sjekket i nettleser: original standard, pakkevalg, sammenligning, eksakt 240×240 og 480×480, pause, omstart, rammesteg, loopovergang, skjermmaske, systemuttrykk og mobilbredde.
- Uten JavaScript vises stillbildegallerier for både originalene og de 21 kandidatene.
- Sammenligningsvisningen bruker hver fils egen varighet; ingen GIF-forsinkelser brukes som EAF-tidslinje.
- Felles rigg og geometriske masker er inspisert. De fire første uttrykkene ble kontrollert før de resterende ble laget. Øynene, pupillene og lysrefleksene er tegnet på nytt, ikke klippet fra referansebildet.
- Ingen nye dekorasjoner, firmwarelogikk, layout, QR-koder, GPIO-er eller systemressurser er innført eller endret.
- Eksisterende ressurspakker er ikke aktivert/erstattet. Kandidaten ble pakket med prosjektets eksisterende verktøy i et separat build-område og alle 21 EAF-payloads er med.

Se STORRELSER.md, report.json, asset-check.json og quality-check.json for tall.

## Begrensninger

Ingen fysisk Puppy er testet. Faktisk FPS, intern minnebruk, lydlast, SPI/DMA og skjermorientering må kontrolleres på roboten. Pakkeprøven gjelder domestic-region med eksisterende originale font- og WakeNet-ressurser. Vi har ikke endret eller testet produsentens LLM-tjeneste. Kandidatene bruker de samme følelsesnavnene som originalene.
