# Filstørrelser og kontroller: puppy-eyes-v2

| Følelse | Bilder | FPS | Sekunder | Original (byte) | Kandidat (byte) | Endring |
|---|---:|---:|---:|---:|---:|---:|
| neutral | 135 | 30 | 4.50 | 206002 | 88679 | -57.0% |
| happy | 72 | 30 | 2.40 | 169844 | 114429 | -32.6% |
| sad | 102 | 30 | 3.40 | 87852 | 127691 | +45.3% |
| angry | 72 | 30 | 2.40 | 245802 | 123041 | -49.9% |
| surprised | 54 | 30 | 1.80 | 106328 | 97521 | -8.3% |
| thinking | 102 | 30 | 3.40 | 151956 | 194569 | +28.0% |
| winking | 54 | 30 | 1.80 | 62002 | 49275 | -20.5% |
| cool | 90 | 30 | 3.00 | 203842 | 133885 | -34.3% |
| laughing | 72 | 30 | 2.40 | 46820 | 129205 | +176.0% |
| loving | 90 | 30 | 3.00 | 145110 | 153587 | +5.8% |
| crying | 84 | 30 | 2.80 | 146892 | 202347 | +37.8% |
| confused | 84 | 30 | 2.80 | 106266 | 175147 | +64.8% |
| embarrassed | 90 | 30 | 3.00 | 105150 | 137489 | +30.8% |
| sleepy | 120 | 30 | 4.00 | 108412 | 242139 | +123.4% |
| confident | 84 | 30 | 2.80 | 59782 | 124157 | +107.7% |
| delicious | 84 | 30 | 2.80 | 49992 | 184609 | +269.3% |
| kiss | 60 | 30 | 2.00 | 84134 | 85457 | +1.6% |
| relaxed | 120 | 30 | 4.00 | 84548 | 59227 | -29.9% |
| shocked | 78 | 30 | 2.60 | 114566 | 127323 | +11.1% |
| silly | 72 | 30 | 2.40 | 149380 | 217555 | +45.6% |
| proud | 90 | 30 | 3.00 | 160075 | 147899 | -7.6% |

Totalt for de 21 følelsene: original 2,594,755 byte (2.47 MiB); kandidat 2,915,231 byte (2.78 MiB), endring +12.4%.

Faktisk pakket kandidat med eksisterende systemressurser, font og WakeNet: 5,455,376 byte av 8,388,608 byte (65.0%). Ledig: 2,933,232 byte.

Den nye pakkens lange tidslinjer inneholder pauser, og EAF-tabellen gjenbruker identiske bildedata. Den oppgitte FPS-en gjelder tidslinjen, også under pauser. En liten fil alene beviser ikke at avspillingen holder 30 FPS på fysisk maskinvare.

Bekreftet: 21 EAF-filer med korrekt kontrollsum, dimensjoner, full dekoding, rett varighet, sirkelsikker margin, pauser og sømløse endepunkter. Kandidatmanifestet endrer nøyaktig de 21 følelsene. Alle 32 beskyttede originalfiler er byteidentiske med før arbeidet. Ingen systemfil er inkludert i kandidatens emoji-mappe.

Ressurspakketesten er kjørt med domestic-regionens uendrede Wi-Fi-grafikk og eksisterende font og WakeNet. Den aktiverer ikke pakken og endrer ikke originalens byggartefakter. Se asset-check.json.

Ikke bekreftet: faktisk FPS under lyd/robotlast, fysisk skjermorientering, SPI/DMA-oppførsel eller maskinvareavspilling. Ingen robot er koblet til. Ingen endring er gjort i samtaletjenesten.
