(function(){'use strict';
const $=id=>document.getElementById(id),D=ALIVE_DATA,names=D.names;globalThis.ALIVE_NAMES=names;
const engine=new EmotionEngine();let clips=[null,null],entries=[null,null],elapsed=0,playing=true,last=null,sequence=null,simulating=false,blend=null,error=false;
const contexts=[$('a').getContext('2d'),$('b').getContext('2d')];
const packLabels={original:'Original',v2:'Puppy Eyes V2',alive:'Puppy Alive V1'};
function option(value,label=value){const o=document.createElement('option');o.value=value;o.textContent=label;return o;}
names.forEach(n=>$('emotion').append(option(n,n+(D.extensions.includes(n)?' · utvidelse':''))));
Object.keys(D.transitions).forEach(n=>$('transition').append(option(n)));
Object.entries(D.clips).forEach(([key,e])=>$('clip').append(option(key,e.kind+' · '+e.name)));
function entry(pack,name,level){return D.packs[pack]?.[name]?.[pack==='alive'?level:'medium']||null;}
function decode(e){return e?EafCodec.decode(Uint8Array.from(atob(e.data),c=>c.charCodeAt(0))):null;}
function load(){
 elapsed=0;blend=null;error=false;
 try{['left','right'].forEach((id,i)=>{
  const pack=$(id).value,e=entry(pack,$('emotion').value,$('level').value);entries[i]=e;clips[i]=decode(e);
  $(id+'-title').textContent=packLabels[pack];
  $('meta-'+(i?'b':'a')).textContent=e?`${e.frames} rammer · ${e.fps} FPS · ${e.seconds.toFixed(2)} s\n${(e.bytes/1024).toFixed(1)} KiB · loop ${e.loop?'ja':'nei'}\nEAF dekodet på PC; robot ikke testet`:'Uttrykket finnes ikke i denne pakken. Ingen erstatning vises.';
  const link=$('gif-'+(i?'b':'a'));link.hidden=!e;if(e)link.href=e.gif;
 });$('scrub').max=Math.max(...entries.map(e=>e?.frames||1))-1;$('status').textContent='';draw();}
 catch(e){error=true;playing=false;$('status').textContent='Feil: '+e.message;throw e;}
}
function mix(a,b,t){const u=Math.max(0,Math.min(1,t)),ease=blend?.ease||'smoother',s=ease==='ease_in'?u*u*u:ease==='ease_out'?1-(1-u)**3:ease==='smoother'?u*u*u*(u*(6*u-15)+10):u*u*(3-2*u);return Object.fromEntries(Object.keys(a).map(k=>[k,a[k]+(b[k]-a[k])*s]));}
// Browser geometric preview of the same anatomical channels. EAF remains the
// authoritative exported raster; canvas AA may differ from Pillow's AA.
function rig(ctx,p){ctx.fillStyle='#000';ctx.fillRect(0,0,240,240);ctx.save();ctx.translate(120,120);ctx.rotate(-p.tilt*Math.PI/180);ctx.translate(-120,-120);
 for(const [side,suffix,center] of [[1,'l',78],[-1,'r',162]]){
 const cx=center+side*p.spread+p.dx,cy=116-p.lift,w=58*p['width_'+suffix],h=76*p['height_'+suffix],blink=p['blink_'+suffix];
 ctx.save();ctx.fillStyle='#fff3de';
 if(blink>=.98){ctx.beginPath();ctx.moveTo(cx-w/2,cy+.05*h);ctx.quadraticCurveTo(cx,cy+.05*h-16,cx+w/2,cy+.05*h);ctx.strokeStyle='#fff3de';ctx.lineWidth=3;ctx.stroke();ctx.restore();continue;}
 ctx.beginPath();ctx.ellipse(cx,cy,w/2,h/2,0,0,Math.PI*2);ctx.clip();ctx.fillRect(cx-w,cy-h,w*2,h*2);
 const top=Math.max(0,Math.min(1,p.top+p['top_'+suffix]+blink*.55)),bottom=Math.max(0,Math.min(1,p.bottom+blink*.45));
 ctx.fillStyle='#000';ctx.beginPath();ctx.moveTo(cx-w/2,cy-h);ctx.lineTo(cx+w/2,cy-h);
 for(let i=60;i>=0;i--){const x=cx-w/2+w*i/60,u=(x-cx)/(w/2);ctx.lineTo(x,cy-h/2+top*h+p.slope*side*(x-cx)-8*blink*(1-u*u));}ctx.closePath();ctx.fill();
 ctx.beginPath();for(let i=0;i<=60;i++){const x=cx-w/2+w*i/60,u=(x-cx)/(w/2);ctx.lineTo(x,cy+h/2-bottom*h-p.smile*h*(1-u*u)-8*blink*(1-u*u));}ctx.lineTo(cx+w/2,cy+h);ctx.lineTo(cx-w/2,cy+h);ctx.closePath();ctx.fill();
 // Use an offscreen mask so pupils never appear through closed eyelids.
 ctx.beginPath();for(let i=0;i<=60;i++){const x=cx-w/2+w*i/60,u=(x-cx)/(w/2);ctx.lineTo(x,cy-h/2+top*h+p.slope*side*(x-cx)-8*blink*(1-u*u));}for(let i=60;i>=0;i--){const x=cx-w/2+w*i/60,u=(x-cx)/(w/2);ctx.lineTo(x,cy+h/2-bottom*h-p.smile*h*(1-u*u)-8*blink*(1-u*u));}ctx.closePath();ctx.clip();
 const px=cx+p.gaze_x+side*p.converge,py=cy+p.gaze_y,r=p.pupil/2;
 ctx.beginPath();ctx.arc(px,py,r,0,Math.PI*2);ctx.fill();ctx.fillStyle='#fff3de';ctx.beginPath();ctx.arc(px-5,py-7,2.25,0,Math.PI*2);ctx.fill();
 // Reapply lids over the pupil/glint (same contours) using a masked layer below.
 ctx.restore();
 }ctx.restore();}
function draw(){
 clips.forEach((clip,i)=>{const ctx=contexts[i];ctx.fillStyle='#000';ctx.fillRect(0,0,240,240);if(!clip)return;
 const e=entries[i],index=e.loop?Math.floor(elapsed*e.fps/1000+1e-7)%clip.frames.length:Math.min(clip.frames.length-1,Math.floor(elapsed*e.fps/1000+1e-7));
 if(i===0&&blend){rig(ctx,mix(blend.a,blend.b,(engine.now-blend.start)/blend.ms));}
 else if(i===0&&!$('micro').checked&&e.basePoses){const p=e.basePoses[index];rig(ctx,p);}
 else ctx.putImageData(new ImageData(clip.frames[index],240,240),0,0);
 });
 const count=Math.max(...entries.map(e=>e?.frames||1)),f=Math.floor(elapsed*30/1000+1e-7)%count;$('scrub').value=f;$('frame').textContent=`${f+1} / ${count}`;
}
function showVisible(name){
 if(names.includes(name)){setEmotion(name,engine.intensity<.34?'low':engine.intensity>.7?'high':'medium');return;}
 entries[0]=D.system[name]||null;clips[0]=decode(entries[0]);elapsed=0;blend=null;
 $('meta-a').textContent=entries[0]?`${name} · original systemressurs · ${entries[0].fps} FPS`:`Systemlås: ${name} (ingen original animasjonsressurs)`;draw();
}
function resetEngine(){engine.reset();$('system').value='';$('conversation').value='idle';}
function displayEngine(){ $('engine-state').textContent=JSON.stringify({time_ms:Math.round(engine.now),visible:engine.visible(),emotion:engine.current,intensity:engine.intensity,conversation:engine.state,attention:engine.attention,system:engine.system},null,2);}
function setEmotion(name,level){if(names.includes(name)){$('emotion').value=name;$('level').value=level;load();}}
function issue(message){const old=entries[0]?.poses?.[Math.floor(elapsed*30/1000+1e-7)%entries[0].frames];
 if(engine.receive(message)){const level=engine.intensity<.34?'low':engine.intensity>.7?'high':'medium';setEmotion(engine.current,level);
 const profile=D.transitions[$('transition').value];if(profile&&old&&entries[0]?.poses){blend={a:old,b:entries[0].poses[0],start:engine.now,ms:profile[2]*1000,ease:profile[3]};}
 $('status').textContent='Lokal testmelding mottatt.';
 }else $('status').textContent='Systemtilstanden har prioritet. Meldingen ble avvist.';displayEngine();}
function frame(time){const dt=last===null?0:Math.min(100,time-last);last=time;
 if(playing&&!error){elapsed+=dt*Number($('speed').value);if(simulating){const prior=engine.visible();engine.advance(dt);
  if(sequence){while(sequence.length&&engine.now>=sequence[0].at){const e=sequence.shift();issue(e.message);}if(!sequence.length)sequence=null;}
  const visible=engine.visible();if(visible!==prior)showVisible(visible);
  if(blend&&engine.now-blend.start>=blend.ms)blend=null;displayEngine();}
 draw();}requestAnimationFrame(frame);}
for(const id of ['emotion','level','left','right'])$(id).addEventListener('change',()=>{simulating=false;sequence=null;load();});
$('play').onclick=()=>{playing=!playing;$('play').textContent=playing?'Pause':'Spill av';};
$('stop').onclick=()=>{playing=false;simulating=false;sequence=null;blend=null;elapsed=0;$('play').textContent='Spill av';draw();};
$('attention').oninput=()=>{engine.setAttention(Number($('attention').value));displayEngine();};
$('restart').onclick=()=>{elapsed=0;draw();};
function step(n){playing=false;$('play').textContent='Spill av';elapsed=Math.max(0,elapsed+n*1000/30);draw();}
$('previous').onclick=()=>step(-1);$('next').onclick=()=>step(1);$('scrub').oninput=()=>{playing=false;$('play').textContent='Spill av';elapsed=Number($('scrub').value)*1000/30;draw();};
$('scale').onchange=()=>{for(const id of ['a','b']){$(id).style.width=240*Number($('scale').value)+'px';$(id).style.height='auto';}};
$('png').onclick=()=>{const a=document.createElement('a');a.href=$('a').toDataURL();a.download='puppy-'+$('emotion').value+'.png';a.click();};
$('apply').onclick=()=>{simulating=true;sequence=null;issue({emotion:$('emotion').value,intensity:{low:.2,medium:.5,high:.9}[$('level').value],duration_ms:Number($('duration').value)});};
$('send').onclick=()=>{try{simulating=true;sequence=null;issue(JSON.parse($('message').value));}catch(e){$('status').textContent='Feil: '+e.message;}};
$('system').onchange=()=>{engine.setSystem($('system').value||null);simulating=true;showVisible(engine.visible());displayEngine();$('status').textContent=engine.system?'Systemtilstand aktiv; originale systemressurser har prioritet.':'Systemprioritet frigitt.';};
$('conversation').onchange=()=>{engine.conversation($('conversation').value);simulating=true;showVisible(engine.visible());displayEngine();};
$('idle').onclick=()=>{resetEngine();engine.setAttention(Number($('attention').value));simulating=true;sequence=null;setEmotion('neutral',engine.attention<.3?'low':engine.attention>.7?'high':'medium');playing=true;$('play').textContent='Pause';};
$('stop-demo').onclick=()=>{simulating=false;sequence=null;blend=null;};
$('demo').onclick=()=>{resetEngine();simulating=true;setEmotion('neutral','medium');playing=true;$('play').textContent='Pause';sequence=[{at:6000,message:{emotion:'attentive',duration_ms:2000}},{at:9000,message:{emotion:'thinking',duration_ms:3000}},{at:12500,message:{emotion:'curious',duration_ms:3000}},{at:16500,message:{emotion:'happy',duration_ms:3000}}];};
$('show-clip').onclick=()=>{simulating=false;sequence=null;blend=null;const e=D.clips[$('clip').value];entries[0]=e;clips[0]=decode(e);elapsed=0;playing=true;$('play').textContent='Pause';$('meta-a').textContent=`${e.name} · ${e.frames} rammer · ${e.fps} FPS · loop ${e.loop}`;draw();};
for(const name of names){const fig=document.createElement('figure'),e=entry('alive',name,'medium'),img=new Image();img.src=e.gif;img.width=144;img.height=144;img.loading='lazy';img.alt=name;const caption=document.createElement('figcaption');caption.textContent=name+(D.extensions.includes(name)?' · utvidelse':'');fig.append(img,caption);fig.onclick=()=>{$('emotion').value=name;load();window.scrollTo({top:0,behavior:'smooth'});};$('gallery').append(fig);}
$('old').ontoggle=()=>{if($('old').open&&!$('legacy').src)$('legacy').src=$('legacy').dataset.src;};
load();displayEngine();requestAnimationFrame(frame);
// Exposed only for deterministic host validation, no network integration.
globalThis.AliveViewer={engine,load,draw,issue,setEmotion,get clips(){return clips;},get entries(){return entries;},rig};
})();
