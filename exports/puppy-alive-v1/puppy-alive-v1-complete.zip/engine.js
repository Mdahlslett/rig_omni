/* Host-only emotion state machine. Does not modify Luwu's wire protocol. */
(function(root){'use strict';
class EmotionEngine {
 constructor(){this.reset();}
 reset(){this.current='neutral';this.intensity=.5;this.deadline=Infinity;this.state='idle';this.attention=.5;this.system=null;this.queue=[];this.now=0;this.history=[];}
 setAttention(value){if(!Number.isFinite(value)||value<0||value>1)throw Error('Oppmerksomhet må være 0–1');this.attention=value;}
 setSystem(name){if(name!==null&&!['launch','wificonfig','calibration','nvs_reset','remote_mode','error'].includes(name))throw Error('Ukjent systemtilstand');this.system=name;this.history.push({time:this.now,system:name});}
 conversation(state){if(!['idle','listening','thinking','speaking'].includes(state))throw Error('Ukjent samtalestatus');this.state=state;}
 receive(message){
  if(!message||typeof message.emotion!=='string'||!root.ALIVE_NAMES.includes(message.emotion))throw Error('Ukjent eller manglende følelse');
  // intensity/duration_ms are a LOCAL preview interface, not documented wire fields.
  const intensity=message.intensity??.5,duration=message.duration_ms??3000;
  if(typeof intensity!=='number'||!Number.isFinite(intensity)||intensity<0||intensity>1)throw Error('Intensitet må være 0–1');
  if(typeof duration!=='number'||!Number.isFinite(duration)||duration<100||duration>60000)throw Error('Varighet må være 100–60000 ms');
  if(this.system)return false;
  this.current=message.emotion;this.intensity=intensity;this.deadline=this.now+duration;this.history.push({time:this.now,emotion:this.current});return true;
 }
 advance(ms){if(!Number.isFinite(ms)||ms<0)throw Error('Ugyldig tid');this.now+=ms;if(this.now>=this.deadline){this.current='neutral';this.deadline=Infinity;}}
 visible(){return this.system|| (this.current==='neutral'&&this.state==='listening'?'listen':this.current==='neutral'&&this.state==='thinking'?'thinking':this.current);}
}
root.EmotionEngine=EmotionEngine;if(typeof module!=='undefined')module.exports=EmotionEngine;
})(globalThis);
