const {chromium}=require('playwright'),assert=require('assert/strict'),fs=require('fs'),path=require('path'),os=require('os'),{execFileSync}=require('child_process');
const root=path.resolve(__dirname,'../../..'),out=path.join(root,'build/puppy-alive-v1');
const ALWAYS_EXTENSION=['curious','skeptical','attentive','uncertain','excited','worried','mischievous','grateful'];
let target=process.argv[2]||path.join(out,'dist');
if(target.endsWith('.zip')){const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'alive-release-'));execFileSync('python3',['-c','import zipfile,sys;zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])',target,tmp]);target=tmp;}
(async()=>{const browser=await chromium.launch({headless:true});let selections=0,clips=0,native=0;const errors=[];
try{
 const context=await browser.newContext({offline:true,acceptDownloads:true,viewport:{width:1280,height:1000}});const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
 await page.goto('file://'+path.join(target,'START-HER.html'));await page.waitForFunction(()=>!!globalThis.AliveViewer);assert.equal(await page.locator('#emotion option').count(),29);
 const names=await page.locator('#emotion option').evaluateAll(os=>os.map(o=>o.value));
 for(const name of names)for(const level of ['low','medium','high']){
  await page.locator('#emotion').selectOption(name);await page.locator('#level').selectOption(level);
  const state=await page.evaluate(()=>({count:AliveViewer.clips[0]?.frames.length,pixels:AliveViewer.clips[0]?.frames[0].some((v,i)=>i%4!==3&&v>0),level:AliveViewer.entries[0]?.level}));
  assert.ok(state.count>1&&state.pixels);assert.equal(state.level,level);selections++;
 }
 console.log('87 intensity selections passed');
 for(const [a,b] of [['original','v2'],['original','alive'],['v2','alive']]){
  await page.locator('#left').selectOption(a);await page.locator('#right').selectOption(b);
  for(const n of names){await page.locator('#emotion').selectOption(n);const counts=await page.evaluate(()=>AliveViewer.clips.map(c=>c?.frames.length||0));if(a==='alive'||b==='alive'||!ALWAYS_EXTENSION.includes(n))assert.ok(counts.some(n=>n>0));if(['curious','skeptical','attentive','uncertain','excited','worried','mischievous','grateful'].includes(n)){if(a!=='alive')assert.equal(counts[0],0);if(b!=='alive')assert.equal(counts[1],0);}selections++;}
 }
 await page.locator('#left').selectOption('alive');await page.locator('#emotion').selectOption('happy');
 await page.locator('#play').click();await page.locator('#scrub').fill('10');await page.locator('#next').click();assert.match(await page.locator('#frame').innerText(),/^12 /);
 await page.locator('#scale').selectOption('2');await page.screenshot({path:path.join(out,'browser-comparison.png'),fullPage:true});
 await page.locator('#micro').uncheck();await page.locator('#next').click();await page.locator('#micro').check();
 const download=page.waitForEvent('download');await page.locator('#png').click();assert.match((await download).suggestedFilename(),/\.png$/);
 for(const key of await page.locator('#clip option').evaluateAll(os=>os.map(o=>o.value))){await page.locator('#clip').selectOption(key);await page.locator('#show-clip').click();assert.ok(await page.evaluate(()=>AliveViewer.clips[0].frames.length>1));clips++;}
 for(const name of await page.locator('#transition option').evaluateAll(os=>os.map(o=>o.value).filter(v=>v!=='none'))){await page.locator('#transition').selectOption(name);await page.locator('#message').fill('{"emotion":"happy","duration_ms":3000}');await page.locator('#send').click();assert.match(await page.locator('#status').innerText(),/mottatt/);}
 await page.locator('#system').selectOption('calibration');assert.equal(await page.evaluate(()=>AliveViewer.entries[0].name),'calibration');await page.locator('#send').click();assert.match(await page.locator('#status').innerText(),/avvist/);await page.locator('#system').selectOption('');
 await page.locator('#message').fill('{"emotion":"curious","intensity":0.65,"duration_ms":100}');await page.locator('#send').click();await page.waitForFunction(()=>AliveViewer.engine.current==='neutral');
 await page.locator('#conversation').selectOption('listening');assert.equal(await page.evaluate(()=>AliveViewer.entries[0].name),'listen');await page.locator('#conversation').selectOption('idle');
 await page.locator('#message').fill('{broken');await page.locator('#send').click();assert.match(await page.locator('#status').innerText(),/Feil/);
 await page.locator('#demo').click();await page.evaluate(()=>{AliveViewer.engine.advance(6500);});await page.waitForFunction(()=>AliveViewer.engine.current==='attentive');await page.locator('#stop-demo').click();
 await page.locator('#old').evaluate(e=>e.open=true);await page.frameLocator('#legacy').locator('.native-expression img').first().waitFor({state:'attached'});await page.frameLocator('#legacy').locator('.native-expression img').first().evaluate(i=>{i.loading='eager';return Promise.race([i.decode(),new Promise((_,reject)=>setTimeout(()=>reject(Error('Legacy image did not decode')),5000))]);});
 await page.setViewportSize({width:390,height:844});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 await page.screenshot({path:path.join(out,'browser-mobile.png'),fullPage:true});
 console.log('Interactive controls and embedded legacy viewer passed');
 const nojs=await browser.newContext({offline:true,javaScriptEnabled:false});const gallery=await nojs.newPage();await gallery.goto('file://'+path.join(target,'gallery.html'));
 for(const img of await gallery.locator('img').all()){await img.evaluate(i=>{i.loading='eager';return i.decode();});assert.deepEqual(await img.evaluate(i=>[i.naturalWidth,i.naturalHeight]),[240,240]);native++;}
 assert.equal(native,71);assert.deepEqual(errors,[]);
 const result={emotion_and_comparison_selections:selections,clips,offline_native_gifs:native,three_pack_pairs:true,missing_extensions_explicit:true,playground:true,system_priority:true,local_file:true,png_export:true,mobile_no_overflow:true,page_errors:errors,browser:'Chromium',archive:process.argv[2]||null};
 fs.writeFileSync(path.join(out,process.argv[2]?'validation-release.json':'validation-browser.json'),JSON.stringify(result,null,2));console.log(result);
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exit(1);});
