const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert/strict');
const codec=require('../codec.js');
const out=path.resolve(__dirname,'../../../build/puppy-alive-v1'),report=JSON.parse(fs.readFileSync(path.join(out,'report.json')));let frames=0;
for(const row of report.rows){
 const bytes=fs.readFileSync(path.join(out,row.eaf)),clip=codec.decode(bytes);
 assert.equal(clip.width,240);assert.equal(clip.height,240);assert.equal(clip.frames.length,row.frames);
 clip.frames.forEach((frame,i)=>assert.equal(crypto.createHash('sha256').update(frame).digest('hex'),row.frame_hashes[i],`${row.name}/${row.level}/${i}`));
 assert.throws(()=>codec.decode(bytes.subarray(0,bytes.length-1)));
 const broken=Buffer.from(bytes);broken[broken.length-1]^=1;assert.throws(()=>codec.decode(broken));frames+=clip.frames.length;
}
const result={eaf_files:report.rows.length,exact_rgba_frames:frames,corruption_detected:true,decoder:'Existing strict JS codec following installed C decoder',hardware_tested:false};
fs.writeFileSync(path.join(out,'validation-eaf.json'),JSON.stringify(result,null,2));console.log(result);
