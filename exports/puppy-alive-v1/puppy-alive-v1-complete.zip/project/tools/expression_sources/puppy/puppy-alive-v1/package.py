"""Build portable three-pack viewer; preserve previous viewer as a nested tool."""
import base64,html,json,shutil,sys,zipfile,subprocess
from pathlib import Path
from emotions import definitions,pose,COMPATIBILITY
from export import ROOT,OUT,HERE

DIST=OUT/'dist'

def asset(source,gif,fps,loop,name,level='medium',poses=None):
 b=source.read_bytes()
 from analyze_eaf import parse_file
 _,_,parsed=parse_file(str(source));count=sum(i.get('bit_depth')==8 for _,_,i in parsed)
 return dict(name=name,level=level,fps=fps,loop=loop,frames=count,seconds=count/fps,bytes=len(b),
             data=base64.b64encode(b).decode(),gif=gif,poses=poses)

def stage_assets(profile):
 stage=OUT/('asset-check-'+profile)
 for name in ['packer','res','config']:(stage/name).mkdir(parents=True,exist_ok=True)
 for p in (ROOT/'tools/spiffs_assets').glob('*.py'):shutil.copy2(p,stage/'packer'/p.name)
 entries=json.loads((OUT/'manifests/standard-emote.json').read_text())
 if profile=='extended':entries+=json.loads((OUT/'manifests/extensions-emote.json').read_text())
 if profile=='extended-intensity':
  entries+=json.loads((OUT/'manifests/extensions-emote.json').read_text())
  for n in definitions():
   for level in ['low','high']:entries.append(dict(emote=n+'_'+level,src=f'puppy-alive-v1-{n}-{level}.eaf',fps=30,loop=True))
 for entry in entries:
  name=entry['src']
  if name.startswith('puppy-alive-v1-'):
   expr=name[len('puppy-alive-v1-'):-4];level='medium'
   if expr.endswith(('-low','-high')):expr,level=expr.rsplit('-',1)
   source=OUT/'emotion'/level/(expr+'.eaf')
  else:
   source=ROOT/'main/boards/puppy/emoji'/name
   if name=='wificonfig.eaf':source=source.with_name('wificonfig_domestic.eaf')
  shutil.copy2(source,stage/'res'/name)
 (stage/'config/emote.json').write_text(json.dumps(entries,indent=2))
 shutil.copy2(ROOT/'main/boards/puppy/240_240/layout.json',stage/'config/layout.json')
 # Run genuine packer only if raw resources can plausibly fit. Record all-profile
 # rejection explicitly rather than truncate expressions or activate a subset.
 size=sum(p.stat().st_size for p in (stage/'res').iterdir())
 if size>=0x800000:return dict(profile=profile,resource_bytes=size,fits=False,reason='EAF resources alone exceed partition')
 result=subprocess.run([sys.executable,str(stage/'packer/build.py'),'--res_path',str(stage/'res'),
  '--target_board',str(stage/'config'),'--text_font',str(ROOT/'tools/spiffs_assets/build/assets/font_puhui_common_20_4.bin'),
  '--wakenet_model',str(ROOT/'build/puppy/wakenet_staging'),'--assets_size','0x800000'],capture_output=True,text=True)
 (stage/'packer.log').write_text(result.stdout+result.stderr)
 if result.returncode:return dict(profile=profile,resource_bytes=size,fits=False,reason='Packer rejected profile; see packer.log')
 binary=(stage/'packer/build/assets.bin').read_bytes()
 assert len(binary)<=0x800000
 for p in (stage/'res').glob('*.eaf'):assert p.read_bytes() in binary,p
 index=json.loads((stage/'packer/build/assets/index.json').read_text())
 assert index['layout']==json.loads((ROOT/'main/boards/puppy/240_240/layout.json').read_text())
 actual={e['name']:e for e in index['emoji_collection']}
 for entry in entries:
  assert actual[entry['emote']]['file']==entry['src'];assert not actual[entry['emote']].get('eaf',{}).get('lack',False)
 return dict(profile=profile,resource_bytes=size,packed_bytes=len(binary),fits=True,free_bytes=0x800000-len(binary),region='domestic',all_references_verified=True)

def package():
 sys.path.insert(0,str(ROOT/'tools'))
 defs=definitions();report=json.loads((OUT/'report.json').read_text())
 DIST.mkdir(exist_ok=True)
 for f in ['index.html','app.js','engine.js']:shutil.copy2(ROOT/'tools/expression_viewer/alive'/f,DIST/('START-HER.html' if f=='index.html' else f))
 shutil.copy2(ROOT/'tools/expression_viewer/codec.js',DIST/'codec.js')
 legacy=ROOT/'build/puppy-viewer-ready'
 assert (legacy/'START-HER.html').exists(),'Rebuild previous portable viewer first'
 shutil.copytree(legacy,DIST/'legacy',dirs_exist_ok=True)
 packs={p:{} for p in ['original','v2','alive']};system={};clips={}
 active=json.loads((ROOT/'main/boards/puppy/240_240/emote.json').read_text())
 for e in active:
  n=e['emote'];filename=e['src']
  if filename=='wificonfig.eaf':filename='wificonfig_domestic.eaf'
  gif='legacy/previews/original/'+filename.replace('.eaf','.gif')
  a=asset(ROOT/'main/boards/puppy/emoji'/filename,gif,e['fps'],e['loop'],n)
  if n in defs:packs['original'][n]={'medium':a}
  else:system[n]=a
 v2=HERE.parent/'puppy-eyes-v2'
 for e in json.loads((v2/'240_240/emote.json').read_text()):
  n=e['emote']
  if n in defs and e['src'].startswith('puppy-eyes-v2-'):
   packs['v2'][n]={'medium':asset(v2/'emoji'/e['src'],'legacy/previews/puppy-eyes-v2/'+n+'.gif',e['fps'],e['loop'],n)}
 for row in report['rows']:
  relative='previews/'+row['gif'];dest=DIST/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(OUT/row['gif'],dest)
  assert (DIST/relative).is_file()
  a=asset(OUT/row['eaf'],relative,row['fps'],row['loop'],row['name'],row['level'],row.get('poses'))
  if row['kind']=='emotion':
   a['basePoses']=[pose(row['name'],row['level'],i/(row['frames']-1),report['seed'],micro=False) for i in range(row['frames'])]
   packs['alive'].setdefault(row['name'],{})[row['level']]=a
  else:a['kind']=row['kind'];clips[row['kind']+'/'+row['name']]=a
 from transitions import PROFILES
 data=dict(names=list(defs),extensions=[n for n,d in defs.items() if d['extension']],packs=packs,system=system,clips=clips,transitions=PROFILES,seed=report['seed'])
 (DIST/'data.js').write_text('globalThis.ALIVE_DATA='+json.dumps(data,separators=(',',':'))+';\n')
 gallery='<!doctype html><meta charset="utf-8"><title>Puppy Alive GIF-galleri</title><style>body{background:#171b21;color:#fff;font:16px system-ui;padding:20px}main{display:flex;flex-wrap:wrap;gap:20px}figure{margin:8px}img{width:240px;height:240px;border-radius:50%}a{color:#abd8ff}</style><h1>Puppy Alive V1 – GIF-galleri</h1><a href="START-HER.html">Til vieweren</a>'
 for pack,label in [('original','Original'),('v2','Puppy Eyes V2'),('alive','Puppy Alive V1')]:
  gallery+='<h2>'+label+'</h2><main>'
  for n in defs:
   a=packs[pack].get(n,{}).get('medium')
   gallery+='<figure>'+('<img loading="lazy" width="240" height="240" src="'+a['gif']+'" alt="'+n+'">' if a else '<p>Finnes ikke i denne pakken</p>')+'<figcaption>'+n+('</figcaption></figure>')
  gallery+='</main>'
 (DIST/'gallery.html').write_text(gallery)
 for pack in packs.values():
  for variants in pack.values():
   for entry in variants.values():assert (DIST/entry['gif']).is_file(),entry['gif']
 (DIST/'LES-MEG.txt').write_text('Pakk ut HELE ZIP-filen. Åpne START-HER.html i nettleseren. Ingen installasjon eller internett er nødvendig. Behold mapper og JS-filer sammen. gallery.html fungerer også uten JavaScript. Ingen firmware er endret eller flashet. Se docs/README.md.\n')
 resources=[stage_assets(p) for p in ['standard','extended','extended-intensity']]
 (OUT/'resources.json').write_text(json.dumps(dict(partition_bytes=0x800000,profiles=resources,all_preview_eaf_bytes=report['total_eaf_bytes'],rgb565_full_frame_bytes=115200,double_stripe_psram_bytes=15360,internal_dma_bounce_bytes=15360,hardware_tested=False),indent=2)+'\n')
 return data

if __name__=='__main__':package()
