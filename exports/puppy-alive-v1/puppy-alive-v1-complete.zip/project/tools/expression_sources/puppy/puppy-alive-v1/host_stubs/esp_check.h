#pragma once
#define ESP_GOTO_ON_FALSE(cond, code, label, tag, ...) do { if(!(cond)) {ret=(code);goto label;} } while(0)
