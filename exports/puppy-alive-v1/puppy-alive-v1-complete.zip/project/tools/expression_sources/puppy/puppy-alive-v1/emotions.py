"""One editable definition set; V2 geometry/keyframes reused without modifying V2."""
import importlib.util
import json
from functools import lru_cache
from pathlib import Path
from animation import primitive, idle_schedule, apply, bounded

HERE=Path(__file__).resolve().parent
V2=HERE.parent/'puppy-eyes-v2'
spec=importlib.util.spec_from_file_location('alive_shared_eye_rig',V2/'face.py')
rig=importlib.util.module_from_spec(spec);spec.loader.exec_module(rig)
# Same anatomical rig, antialiasing and colors as V2. No copy of the renderer.
DEFAULTS=rig.DEFAULTS
BASE=json.loads((V2/'animations.json').read_text())
EXTRA={
 'curious':('Nysgjerrig',dict(height_l=1.12,height_r=.93,tilt=5,gaze_x=7,gaze_y=-4,pupil=35)),
 'skeptical':('Skeptisk',dict(top_l=.39,top_r=.04,tilt=-3,gaze_x=-6,pupil=29)),
 'attentive':('Oppmerksom',dict(height_l=1.08,height_r=1.08,pupil=28,lift=3,converge=1)),
 'uncertain':('Usikker',dict(top_l=.08,top_r=.21,gaze_x=-5,gaze_y=3,tilt=3,width_l=.95)),
 'excited':('Begeistret',dict(smile=.2,lift=6,height_l=1.16,height_r=1.16,pupil=36,spread=-2)),
 'worried':('Bekymret',dict(top=.17,slope=-.27,pupil=26,gaze_y=-2,height_l=1.04,height_r=1.04)),
 'mischievous':('Rampete',dict(top_l=.28,top_r=.13,smile=.12,gaze_x=10,tilt=-4,pupil=30)),
 'grateful':('Takknemlig',dict(smile=.24,top=.08,pupil=36,lift=1,spread=-1)),
}
COMPATIBILITY=dict(curious='thinking',skeptical='confused',attentive='neutral',uncertain='confused',
 excited='happy',worried='sad',mischievous='silly',grateful='loving',proud='confident')
# Personality cues add deliberate pauses and different motion vocabulary per emotion.
CUES={
 'happy':[('slow_blink',.9,.65)], 'sad':[('look_down',1.1,.8)],
 'angry':[('focus',.7,1)], 'surprised':[('contract',.45,1)],
 'thinking':[('look_up',.6,1),('side_glance',1.8,.65)],
 'winking':[('pupil_shift',.8,.7)], 'cool':[('side_glance',.8,.8)],
 'laughing':[('partial_blink',.5,1),('partial_blink',1.2,1)],
 'loving':[('slow_blink',1.3,.65)], 'crying':[('double_blink',1.0,1)],
 'confused':[('lid_asymmetry',.7,1),('look_left',1.4,.65)],
 'embarrassed':[('look_down',.7,1),('look_right',1.6,.65)],
 'sleepy':[('slow_blink',1.8,1)], 'confident':[('focus',.8,.8)],
 'delicious':[('slow_blink',1.0,.8)], 'kiss':[('dilate',.7,.8)],
 'relaxed':[('wander',.65,.35)], 'shocked':[('contract',.7,1.3),('fast_blink',1.8,1)],
 'silly':[('look_diagonal',.7,1),('look_left',1.4,1)],
 'proud':[('attention',.6,.9),('slow_blink',1.6,.45)],
 'curious':[('look_diagonal',.6,1),('attention',1.8,.8)],
 'skeptical':[('lid_asymmetry',.7,1),('side_glance',1.5,.7)],
 'attentive':[('focus',.8,1)], 'uncertain':[('look_left',.7,.5),('look_right',1.7,.6)],
 'excited':[('attention',.6,1),('partial_blink',1.2,1),('attention',1.8,.8)],
 'worried':[('side_glance',.7,.6),('contract',1.6,.9)],
 'mischievous':[('side_glance',.7,1),('lid_asymmetry',1.6,1)],
 'grateful':[('slow_blink',1.0,.8),('return_center',2.1,1)],
}

@lru_cache(maxsize=8)
def definitions(seed=20261025):
    result={}
    for name,base in BASE.items():
        result[name]={**base,'extension':False}
    result['proud']['keyframes']=[{**k,'pose':{**k['pose'],'top':.12,'top_l':.025,'smile':.12}} if k['pose'] else k for k in result['proud']['keyframes']]
    result['neutral']={**result['neutral'],'seconds':18,'keyframes':[dict(at=0,pose={}),dict(at=1,pose={})]}
    for name,(label,pose) in EXTRA.items():
        result[name]=dict(seconds=3.2,fps=30,representative=.42,description=label,extension=True,
            keyframes=[dict(at=0,pose=pose),dict(at=.18,pose=pose),dict(at=.48,pose={**pose,'lift':pose.get('lift',0)+2}),dict(at=.8,pose=pose),dict(at=1,pose=pose)])
    for name,d in result.items():
        d['micro']=idle_schedule(seed) if name=='neutral' else [primitive(n,delay=t,strength=s) for n,t,s in CUES.get(name,[])]
    return result

LEVELS={'low':.55,'medium':1.,'high':1.3}
SPEED={'low':1.14,'medium':1.,'high':.88}

def duration(definition, level):
    return round(definition['seconds']*SPEED[level]*30)/30

def pose(name, level, t, seed=20261025, micro=True):
    d=definitions(seed)[name]
    raw=rig.pose_at(d['keyframes'],t)
    factor=LEVELS[level]
    p={key:DEFAULTS[key]+(raw[key]-DEFAULTS[key])*factor for key in DEFAULTS}
    if micro:
        seconds=t*d['seconds']
        for event in d['micro']:
            adjusted={**event,'strength':event['strength']*min(1.15,factor)}
            p=apply(p,adjusted,seconds,name)
    # Neutral variants have different pupil baseline, while retaining calm anatomy.
    if name=='neutral':p['pupil']+=(-1 if level=='low' else 1 if level=='high' else 0)
    return bounded(p)
