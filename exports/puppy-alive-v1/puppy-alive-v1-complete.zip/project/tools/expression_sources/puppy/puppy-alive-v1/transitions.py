"""Pose interpolation: host/generator only; not an EAF runtime feature."""
from animation import EASINGS, bounded
from emotions import pose

PROFILES={
 'neutral_happy':('neutral','happy',.55,'ease_out'),
 'happy_neutral':('happy','neutral',.8,'smoother'),
 'neutral_surprised':('neutral','surprised',.3,'ease_out'),
 'neutral_thinking':('neutral','thinking',.7,'ease_in_out'),
 'thinking_happy':('thinking','happy',.55,'ease_out'),
 'happy_sad':('happy','sad',1.1,'smoother'),
 'sad_neutral':('sad','neutral',1.2,'ease_in_out'),
 'neutral_angry':('neutral','angry',.5,'ease_in'),
 'angry_neutral':('angry','neutral',1.,'smoother'),
 'general':('neutral','curious',.7,'smoother'),
}

def interpolate(a,b,t,easing='smoother'):
    u=EASINGS[easing](max(0,min(1,t)))
    return bounded({key:a[key]+(b[key]-a[key])*u for key in a})

def transition(name,t,level='medium',source=None,target=None):
    a,b,_,ease=PROFILES[name]
    return interpolate(source or pose(a,level,.42,micro=False),target or pose(b,level,.42,micro=False),t,ease)
