# Puppy Alive V1 source

Start with `docs/puppy-alive-v1/README.md` in the project root.

This directory is the editable source. `emotions.py` reuses the sibling V2
`animations.json` and `face.py`; include that sibling when moving the generator.
`preserved-hashes.json` records the existing original/V2 state before Alive.
Outputs belong to ignored `build/puppy-alive-v1/`, not the active board directory.

Run `python tools/build_expressions.py` from the repository root. For final
release, run the offline browser test and `release.py`; test the extracted ZIP
again before publishing. See the docs for prerequisites and exact test levels.
