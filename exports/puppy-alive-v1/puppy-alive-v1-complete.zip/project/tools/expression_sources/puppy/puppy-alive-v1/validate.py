"""Validate real images/containers, not just definition counts."""
import hashlib,json,sys,unittest,math
from pathlib import Path
from PIL import Image,ImageSequence,ImageChops
import numpy as np
from emotions import definitions,pose,LEVELS
from animation import PRIMITIVES,primitive,apply,idle_schedule
from transitions import PROFILES,transition
from rendering import render
from export import ROOT,OUT,HERE,originals

class Definitions(unittest.TestCase):
 def test_all_emotions(self):
  self.assertEqual(len(definitions()),29);self.assertEqual(sum(d['extension'] for d in definitions().values()),8)
 def test_deterministic_idle(self):
  self.assertEqual(idle_schedule(3),idle_schedule(3));self.assertNotEqual(idle_schedule(3),idle_schedule(4))
  self.assertTrue(all(0<e['delay']<17 for e in idle_schedule()))
 def test_primitives(self):
  self.assertEqual(len(PRIMITIVES),20)
  for name in PRIMITIVES:
   with self.subTest(name=name):
    e=primitive(name);p=pose('neutral','medium',0,micro=False);p['gaze_x']=6
    samples=[apply(p,e,e['duration']*t,'neutral') for t in [0,.2,.5,.8,1]]
    self.assertEqual(samples[0],samples[-1]);self.assertTrue(any(x!=p for x in samples[1:-1]))
    e['allowed']=['happy'];self.assertEqual(apply(p,e,e['duration']*.5,'sad'),p)
    with self.assertRaises(ValueError):primitive(name,strength=-1)
 def test_transitions(self):
  self.assertEqual(len(PROFILES),10)
  for name,(a,b,_,_) in PROFILES.items():
   self.assertEqual(transition(name,0),pose(a,'medium',.42,micro=False))
   end=transition(name,1);expected=pose(b,'medium',.42,micro=False)
   for k in end:self.assertAlmostEqual(end[k],expected[k],places=10)
   prev=transition(name,0)
   for i in range(1,101):
    p=transition(name,i/100);self.assertTrue(all(math.isfinite(x) for x in p.values()))
    self.assertLess(max(abs(p[k]-prev[k]) for k in p),1);prev=p
 def test_intensity_and_loops(self):
  for n in definitions():
   variants=[]
   for l in LEVELS:
    with self.subTest(name=n,level=l):
     a=render(pose(n,l,0));b=render(pose(n,l,1));self.assertEqual(a.tobytes(),b.tobytes())
     variants.append(hashlib.sha256(b''.join(render(pose(n,l,t)).tobytes() for t in [.2,.42,.6])).hexdigest())
   self.assertEqual(len(set(variants)),3,n)
 def test_preserved(self):self.assertEqual(originals(),json.loads((HERE/'preserved-hashes.json').read_text()))
 def test_manifests(self):
  active=json.loads((ROOT/'main/boards/puppy/240_240/emote.json').read_text());candidate=json.loads((OUT/'manifests/standard-emote.json').read_text())
  self.assertEqual([x['emote'] for x in active],[x['emote'] for x in candidate])
  for a,b in zip(active,candidate):
   if a['emote'] not in definitions():self.assertEqual(a,b)
  ext=json.loads((OUT/'manifests/extensions-emote.json').read_text());self.assertEqual(len(ext),8)
  self.assertTrue(all(x['emote'] not in {e['emote'] for e in active} for x in ext))


def validate_images():
 report=json.loads((OUT/'report.json').read_text());fingerprints={};total=0;largest_jump=0.;warnings=[]
 for row in report['rows']:
  folder=OUT/'frames'/row['kind']/row['level']/row['name'];hashes=[];last=None;timeline=[]
  for path in sorted(folder.glob('*.png')):
   im=Image.open(path).convert('RGBA');assert im.size==(240,240);assert im.getchannel('A').getextrema()==(255,255)
   rgb=im.convert('RGB');bbox=rgb.getbbox();assert bbox,('Empty',path)
   # All lit pixels must fit inside radius 112 (8px margin inside 120px LCD).
   yy,xx=np.ogrid[:240,:240];outside=(xx-119.5)**2+(yy-119.5)**2>112**2
   assert not np.any(np.asarray(rgb)[outside]),('Clipped',path)
   hashes.append(hashlib.sha256(im.tobytes()).hexdigest());timeline.append(im.tobytes())
   if last:
    difference=ImageChops.difference(rgb,last);mean=sum(sum(c*n for n,c in enumerate(difference.getchannel(ch).histogram())) for ch in range(3))/(240*240*3)
    largest_jump=max(largest_jump,mean);assert mean<27,('Sudden large raster jump',path,mean)
   last=rgb;total+=1
  assert hashes==row['frame_hashes'],row['name']
  if row['loop']:assert hashes[0]==hashes[-1],row['name']
  with Image.open(OUT/row['gif']) as gif:
   assert gif.size==(240,240);expanded=[];ms=0;positions=[]
   for frame in ImageSequence.Iterator(gif):
    duration=frame.info.get('duration',0);assert duration>0;positions.append((ms,ms+duration,frame.convert('RGBA').tobytes()));ms+=duration
   expected_ms=round(row['frames']*100/row['fps'])*10;assert ms==expected_ms,(row['name'],ms,expected_ms)
   # Compare each source tick at its rounded GIF start; holds can be merged.
   j=0
   for i,pixels in enumerate(timeline):
    t=round(i*100/row['fps'])*10
    while j<len(positions)-1 and t>=positions[j][1]:j+=1
    assert positions[j][2]==pixels,('GIF/source mismatch',row['name'],i)
  if row['kind']=='emotion' and row['level']=='medium':
   digest=hashlib.sha256(''.join(hashes).encode()).hexdigest();assert digest not in fingerprints,(row['name'],fingerprints.get(digest));fingerprints[digest]=row['name']
 return dict(png_frames=total,gif_files=len(report['rows']),unique_medium_sequences=len(fingerprints),max_mean_rgb_jump=largest_jump,hardware_tested=False)

if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Definitions))
 if not result.wasSuccessful():sys.exit(1)
 result=validate_images();(OUT/'validation-images.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
