"""Deterministic, bounded pose primitives; no ESP32 runtime changes."""
import math
import random

EASINGS = {
    'linear': lambda x:x,
    'ease_in': lambda x:x*x*x,
    'ease_out': lambda x:1-(1-x)**3,
    'ease_in_out': lambda x:x*x*(3-2*x),
    'smoother': lambda x:x*x*x*(x*(6*x-15)+10),
}
# Channels are deltas, except return_center, which blends gaze toward zero.
PRIMITIVES = {
 'blink':dict(blink_l=1,blink_r=1),
 'slow_blink':dict(blink_l=1,blink_r=1),
 'double_blink':dict(blink_l=1,blink_r=1),
 'fast_blink':dict(blink_l=1,blink_r=1),
 'partial_blink':dict(blink_l=.42,blink_r=.42),
 'look_left':dict(gaze_x=-8), 'look_right':dict(gaze_x=8),
 'look_up':dict(gaze_y=-6), 'look_down':dict(gaze_y=6),
 'look_diagonal':dict(gaze_x=6,gaze_y=-5),
 'side_glance':dict(gaze_x=-11,top=.07),
 'wander':dict(gaze_x=7,gaze_y=3),
 'pupil_shift':dict(gaze_x=2,gaze_y=-1),
 'dilate':dict(pupil=5), 'contract':dict(pupil=-5),
 'narrow':dict(top=.15,bottom=.08),
 'lid_asymmetry':dict(top_l=.13,top_r=-.03),
 'attention':dict(lift=3,height_l=.07,height_r=.07,pupil=-2),
 'return_center':{},
 'focus':dict(top=.08,converge=2,pupil=-2),
}
DURATIONS={'slow_blink':.9,'double_blink':.7,'fast_blink':.28,'wander':2.8,'side_glance':.8}

def primitive(name, duration=None, strength=1., delay=0., easing='ease_in_out', allowed=None):
    if name not in PRIMITIVES or easing not in EASINGS: raise ValueError('Unknown primitive/easing')
    duration=duration if duration is not None else DURATIONS.get(name,.45)
    if not .1<=duration<=10 or not 0<=strength<=1.5 or delay<0: raise ValueError('Invalid primitive parameters')
    return dict(name=name,duration=duration,strength=strength,delay=delay,easing=easing,
                allowed=allowed,limits='Clamped eyelids, pupil and gaze; no system-state override')

def envelope(u, easing):
    if not 0<u<1:return 0.
    # Fast closing, slower opening; held gaze uses a broad plateau.
    return EASINGS[easing](min(1.,u/.25,(1-u)/.45))

def apply(pose, event, seconds, emotion):
    result=dict(pose)
    if event.get('allowed') and emotion not in event['allowed']:return result
    u=(seconds-event['delay'])/event['duration']
    if not 0<u<1:return result
    if event['name']=='double_blink':u=(u*2)%1
    amount=envelope(u,event['easing'])*event['strength']
    if event['name']=='return_center':
        for key in ('gaze_x','gaze_y'):result[key]*=1-min(1,amount)
    else:
        for key,value in PRIMITIVES[event['name']].items():
            wave=math.sin(u*math.pi*2) if event['name']=='wander' and key=='gaze_x' else 1
            result[key]+=value*amount*wave
    return bounded(result)

def bounded(pose):
    result=dict(pose)
    for key in ('blink_l','blink_r'):result[key]=max(0,min(1,result[key]))
    for key in ('top','bottom','top_l','top_r'):result[key]=max(-.15,min(.65,result[key]))
    for key in ('width_l','width_r','height_l','height_r'):result[key]=max(.65,min(1.24,result[key]))
    result['pupil']=max(18,min(41,result['pupil']))
    for key in ('gaze_x','gaze_y'):result[key]=max(-12,min(12,result[key]))
    result['tilt']=max(-8,min(8,result['tilt']))
    return result

def idle_schedule(seed=20261025, seconds=18):
    rng=random.Random(seed); events=[]; t=1.6
    while t<seconds-1.5:
        name=rng.choices(['blink','partial_blink','look_left','look_right','pupil_shift','slow_blink'],[5,1,1,1,2,1])[0]
        event=primitive(name,delay=t,strength=rng.uniform(.75,1))
        if t+event['duration']<seconds-.5:events.append(event)
        t+=rng.uniform(2.2,4.1)
    return events
