"""Compile and execute the installed unmodified Espressif EAF decoder on host."""
import ctypes as C
import hashlib,json,subprocess
import numpy as np
from export import ROOT,OUT,HERE

def check():
 component=ROOT/'managed_components/espressif2022__esp_emote_gfx'
 source=component/'src/lib/eaf/gfx_eaf_dec.c'
 if not source.exists():raise SystemExit('Install pinned project managed components before running the actual C-decoder test.')
 library=OUT/'libeaf-host.so'
 subprocess.run(['gcc','-shared','-fPIC','-O2','-include','stdlib.h','-I'+str(HERE/'host_stubs'),'-I'+str(component/'include'),str(source),'-o',str(library)],check=True)
 lib=C.CDLL(str(library));lib.eaf_init.argtypes=[C.c_void_p,C.c_size_t,C.POINTER(C.c_void_p)];lib.eaf_frame_decode.argtypes=[C.c_void_p,C.c_int,C.c_void_p,C.c_size_t,C.c_bool];lib.eaf_deinit.argtypes=[C.c_void_p]
 report=json.loads((OUT/'report.json').read_text());count=0
 for row in report['rows']:
  raw=(OUT/row['eaf']).read_bytes();data=C.create_string_buffer(raw);handle=C.c_void_p()
  assert lib.eaf_init(data,len(raw),C.byref(handle))==0,row['name']
  try:
   out=np.empty((240,240),dtype=np.uint16);rgba=np.empty((240,240,4),dtype=np.uint8);rgba[:,:,3]=255
   for i,expected in enumerate(row['frame_hashes']):
    out.fill(0xdead);assert lib.eaf_frame_decode(handle,i,out.ctypes.data,out.nbytes,False)==0
    r=out>>11;g=(out>>5)&63;b=out&31
    rgba[:,:,0]=(r<<3)|(r>>2);rgba[:,:,1]=(g<<2)|(g>>4);rgba[:,:,2]=(b<<3)|(b>>2)
    assert hashlib.sha256(rgba.tobytes()).hexdigest()==expected,(row['name'],row['level'],i)
    count+=1
  finally:lib.eaf_deinit(handle)
 result=dict(files=len(report['rows']),frames=count,source=str(source.relative_to(ROOT)),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),actual_unmodified_c_decoder=True,host_stubs='ESP logging/error macros; optional JPEG/heatshrink disabled',hardware_tested=False)
 (OUT/'validation-c-decoder.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':check()
