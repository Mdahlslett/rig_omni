"""Create reviewable portable/source ZIPs only after technical checks pass."""
import hashlib,json,shutil,zipfile
from pathlib import Path
from export import ROOT,OUT,HERE,originals
from package import DIST

def files(root):
 return [p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.git' not in p.parts]

def write_zip(path,items):
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p,name in sorted(items,key=lambda x:x[1]):
   # Stable timestamps/order, so release bytes are repeatable for unchanged inputs.
   info=zipfile.ZipInfo(str(name).replace('\\','/'),date_time=(2026,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,p.read_bytes())


def release():
 required=['validation-images.json','validation-eaf.json','validation-c-decoder.json','validation-browser.json','resources.json']
 for name in required:assert (OUT/name).is_file(),f'Missing successful check: {name}'
 assert originals()==json.loads((HERE/'preserved-hashes.json').read_text())
 shutil.copytree(ROOT/'docs/puppy-alive-v1',DIST/'docs',dirs_exist_ok=True)
 (DIST/'reports').mkdir(exist_ok=True)
 for name in required+['report.json','definitions.json','contact-sheet.png','motion-sheet-1.jpg','motion-sheet-2.jpg','motion-sheet-3.jpg','validation-node.txt']:
  shutil.copy2(OUT/name,DIST/'reports'/name)
 viewer=OUT/'puppy-alive-v1-viewer.zip';write_zip(viewer,[(p,p.relative_to(DIST).as_posix()) for p in files(DIST)])
 source=[]
 def add(folder,prefix):
  source.extend((p,prefix+'/'+p.relative_to(folder).as_posix()) for p in files(folder))
 source.extend((p,p.relative_to(DIST).as_posix()) for p in files(DIST))
 for folder in [ROOT/'tools/expression_sources/puppy',ROOT/'tools/expression_viewer',ROOT/'docs/puppy-alive-v1',ROOT/'main/boards/puppy/emoji',ROOT/'main/boards/puppy/240_240',ROOT/'build/puppy-viewer-ready',ROOT/'build/puppy/wakenet_staging']:
  add(folder,'project/'+folder.relative_to(ROOT).as_posix())
 for folder in ['emotion','micro','transition','frames','stills','manifests']:
  add(OUT/folder,'project/build/puppy-alive-v1/'+folder)
 for name in required+['report.json','definitions.json','contact-sheet.png']:
  source.append((OUT/name,'project/build/puppy-alive-v1/'+name))
 for name in ['gif_to_eaf.py','analyze_eaf.py','preview_expressions.py','build_expressions.py']:
  source.append((ROOT/'tools'/name,'project/tools/'+name))
 for p in (ROOT/'tools/spiffs_assets').glob('*.py'):source.append((p,'project/tools/spiffs_assets/'+p.name))
 font=ROOT/'tools/spiffs_assets/build/assets/font_puhui_common_20_4.bin';source.append((font,'project/'+font.relative_to(ROOT).as_posix()))
 component=ROOT/'managed_components/espressif2022__esp_emote_gfx'
 for folder in [component/'src/lib/eaf',component/'include/core']:
  add(folder,'project/'+folder.relative_to(ROOT).as_posix())
 for p in component.glob('*LICENSE*'):source.append((p,'project/'+p.relative_to(ROOT).as_posix()))
 source.append((ROOT/'dependencies.lock','project/dependencies.lock'))
 full=OUT/'puppy-alive-v1-complete.zip';write_zip(full,source)
 report={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [viewer,full]}
 (OUT/'release.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':release()
