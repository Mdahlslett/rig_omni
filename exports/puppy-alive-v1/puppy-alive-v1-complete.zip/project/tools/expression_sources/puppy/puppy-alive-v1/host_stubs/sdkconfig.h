#pragma once
/* Optional codecs deliberately undefined: source uses both #if and #ifdef. */
