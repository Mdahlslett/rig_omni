"""Build all profiles without activating firmware resources."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
from concurrent.futures import ProcessPoolExecutor
from PIL import Image,ImageDraw
from emotions import definitions,pose,duration,LEVELS
from animation import PRIMITIVES,primitive,apply
from transitions import PROFILES,transition
from rendering import render

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
sys.path.insert(0,str(ROOT/'tools'))
from gif_to_eaf import encode_frames
OUT=ROOT/'build/puppy-alive-v1'

def sha(data):return hashlib.sha256(data).hexdigest()

def save_clip(name,level,frames,fps,loop=True,kind='emotion',poses=None):
    folder=OUT/kind/level
    folder.mkdir(parents=True,exist_ok=True)
    eaf=folder/(name+'.eaf'); encode_frames(frames,eaf,deduplicate=True)
    durations=[round((i+1)*100/fps)*10-round(i*100/fps)*10 for i in range(len(frames))]
    gif=folder/(name+'.gif')
    frames[0].save(gif,save_all=True,append_images=frames[1:],duration=durations,loop=0 if loop else 1,disposal=2,optimize=False)
    pngs=OUT/'frames'/kind/level/name;pngs.mkdir(parents=True,exist_ok=True)
    # Numbered editable frames, including repeated hold ticks.
    for i,frame in enumerate(frames):frame.save(pngs/f'{i:04}.png')
    hashes=[sha(f.convert('RGBA').tobytes()) for f in frames]
    row=dict(name=name,level=level,kind=kind,fps=fps,frames=len(frames),seconds=len(frames)/fps,
        loop=loop,eaf=str(eaf.relative_to(OUT)),gif=str(gif.relative_to(OUT)),bytes=eaf.stat().st_size,
        sha256=sha(eaf.read_bytes()),frame_hashes=hashes,unique_frames=len(set(hashes)),
        eaf_status='Host round-trip required; physical hardware untested')
    if poses:row['poses']=poses
    return row

def emotion_job(args):
    name,level,seed=args;d=definitions(seed)[name];count=round(duration(d,level)*30)
    poses=[pose(name,level,i/(count-1),seed) for i in range(count)]
    frames=[render(p) for p in poses]
    row=save_clip(name,level,frames,30,poses=poses)
    rep=round(d.get('representative',.42)*(count-1));
    if name not in ('winking','laughing') and max(poses[rep]['blink_l'],poses[rep]['blink_r'])>.45:
        rep=min(range(count),key=lambda i:abs(i-rep) if max(poses[i]['blink_l'],poses[i]['blink_r'])<.3 else count*2)
    rep_path=OUT/'stills'/level;rep_path.mkdir(parents=True,exist_ok=True)
    frames[rep].save(rep_path/(name+'.png'))
    row.update(extension=d['extension'],description=d['description'])
    print(name,level,count,row['bytes'],flush=True);return row

def originals():
    paths=list((ROOT/'main/boards/puppy/emoji').glob('*.eaf'))+list((ROOT/'main/boards/puppy/240_240').glob('*.json'))
    paths+=list((HERE.parent/'puppy-eyes-v2').rglob('*'))
    # Preserve source and generated V2 artifacts, excluding interpreter caches.
    return {str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in paths if p.is_file() and '__pycache__' not in str(p)}

def generate(seed=20261025,workers=2,only=None):
    OUT.mkdir(parents=True,exist_ok=True)
    baseline=HERE/'preserved-hashes.json'
    if not baseline.exists():baseline.write_text(json.dumps(originals(),indent=2)+'\n')
    assert originals()==json.loads(baseline.read_text()),'Existing resources changed'
    defs=definitions(seed)
    with ProcessPoolExecutor(max_workers=workers) as pool:
        rows=list(pool.map(emotion_job,[(n,l,seed) for n in defs if not only or n in only for l in LEVELS]))
    if only:
        old=json.loads((OUT/'report.json').read_text())
        rows=[r for r in old['rows'] if r['kind']=='emotion' and r['name'] not in only]+rows
        rows.sort(key=lambda r:(list(defs).index(r['name']),list(LEVELS).index(r['level'])))
    for name in PRIMITIVES:
        event=primitive(name)
        n=round(event['duration']*30)+1
        start=pose('neutral','medium',0,micro=False)
        if name=='return_center':start['gaze_x']=8
        frames=[render(apply(start,event,i/(n-1)*event['duration'],'neutral')) for i in range(n)]
        rows.append(save_clip(name,'medium',frames,30,kind='micro'))
    for name,(_,_,seconds,_) in PROFILES.items():
        n=round(seconds*30)+1;poses=[transition(name,i/(n-1)) for i in range(n)]
        rows.append(save_clip(name,'medium',[render(p) for p in poses],30,loop=False,kind='transition',poses=poses))
    manifests=OUT/'manifests';manifests.mkdir(exist_ok=True)
    active=json.loads((ROOT/'main/boards/puppy/240_240/emote.json').read_text())
    standard=[{**e,'src':f"puppy-alive-v1-{e['emote']}.eaf",'fps':30,'loop':True} if e['emote'] in defs else e for e in active]
    (manifests/'standard-emote.json').write_text(json.dumps(standard,indent=2)+'\n')
    extensions=[dict(emote=n,src=f'puppy-alive-v1-{n}.eaf',fps=30,loop=True) for n,d in defs.items() if d['extension']]
    (manifests/'extensions-emote.json').write_text(json.dumps(extensions,indent=2)+'\n')
    from emotions import COMPATIBILITY
    (manifests/'compatibility.json').write_text(json.dumps(COMPATIBILITY,indent=2)+'\n')
    (OUT/'definitions.json').write_text(json.dumps(dict(seed=seed,emotions=defs,levels=LEVELS,primitives={n:primitive(n) for n in PRIMITIVES},transitions=PROFILES),indent=2)+'\n')
    report=dict(pack='puppy-alive-v1',seed=seed,emotions=29,variants=87,micro=20,transitions=10,
        hardware_tested=False,rows=rows,total_eaf_bytes=sum(x['bytes'] for x in rows))
    (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    contact=Image.new('RGB',(5*240,6*268),(18,20,24));draw=ImageDraw.Draw(contact)
    for i,name in enumerate(defs):
        x,y=i%5*240,i//5*268;contact.paste(Image.open(OUT/'stills/medium'/f'{name}.png').convert('RGB'),(x,y));draw.text((x+12,y+244),name,fill='white')
    contact.save(OUT/'contact-sheet.png')
    assert originals()==json.loads(baseline.read_text())
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--seed',type=int,default=20261025);p.add_argument('--workers',type=int,default=2);p.add_argument('--only',help='Comma-separated subset; requires an existing full build')
    args=p.parse_args();generate(args.seed,args.workers,args.only.split(',') if args.only else None)
