"""Reuse V2 anatomy. Smooth its near-closed lid raster and quantize to LCD colors."""
from PIL import Image
from emotions import rig


def render(pose):
    # The old polygon rig can leave tiny corners immediately before full closure.
    # Blend its half-closed mask into the curved closed lid over this short phase.
    # No copied renderer or new facial features, and exactly 32 output colors.
    a=dict(pose);b=dict(pose)
    closing=max(pose['blink_l'],pose['blink_r'])
    for suffix in ('l','r'):
        blink=pose['blink_'+suffix]
        a['blink_'+suffix]=0
        a['height_'+suffix]*=1-.88*min(blink,.65)
        b['blink_'+suffix]=1 if blink>.65 else 0
        b['height_'+suffix]=a['height_'+suffix]
    image=rig.render(a)
    if closing>.65:
        u=(closing-.65)/.35;u=u*u*(3-2*u)
        image=Image.blend(image.convert('RGB'),rig.render(b).convert('RGB'),u).quantize(palette=image,dither=Image.Dither.NONE)
    palette=image.getpalette()
    for i in range(0,len(palette),3):
        r,g,b=palette[i:i+3];r>>=3;g>>=2;b>>=3
        palette[i:i+3]=[(r<<3)|(r>>2),(g<<2)|(g>>4),(b<<3)|(b>>2)]
    image.putpalette(palette)
    return image
