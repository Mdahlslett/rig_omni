#!/usr/bin/env python3
"""Build and validate Puppy Alive without touching active firmware resources."""
import argparse
from pathlib import Path
import subprocess,sys

ROOT=Path(__file__).resolve().parent.parent
SOURCE=ROOT/'tools/expression_sources/puppy/puppy-alive-v1'

def run(*args):subprocess.run(list(map(str,args)),cwd=ROOT,check=True)

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--seed',type=int,default=20261025);p.add_argument('--workers',type=int,default=2);p.add_argument('--skip-c-decoder',action='store_true',help='For machines without GCC/installed managed components; never records a C pass')
 args=p.parse_args()
 run(sys.executable,SOURCE/'export.py','--seed',args.seed,'--workers',args.workers)
 run(sys.executable,SOURCE/'validate.py')
 run('node',ROOT/'tools/expression_viewer/alive/validate_eaf.cjs')
 run('node','--test',ROOT/'tools/expression_viewer/alive/test_engine.cjs',ROOT/'tools/expression_viewer/test_codec.cjs',ROOT/'tools/expression_viewer/test_packs.cjs')
 if not args.skip_c_decoder:run(sys.executable,SOURCE/'validate_c_decoder.py')
 run(sys.executable,SOURCE/'package.py')
 print('Host build validated. Browser release test and release.py remain separate explicit steps; no firmware activated.')
