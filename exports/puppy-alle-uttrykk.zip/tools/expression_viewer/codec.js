/* EAF container layout follows tools/analyze_eaf.py; RLE and palette handling
 * follow esp_emote_gfx/src/lib/eaf/gfx_eaf_dec.c. No firmware code is executed. */
(function (root) {
  "use strict";
  function decode(input) {
    const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const fail = message => { throw new Error(message); };
    const check = (condition, message) => { if (!condition) fail(message); };
    check(bytes.length >= 16, "EAF-filen er for kort.");
    check(bytes[0] === 0x89 && bytes[1] === 69 && bytes[2] === 65 && bytes[3] === 70,
      "Filen har ikke en gyldig EAF-signatur.");
    const count = view.getUint32(4, true);
    check(count > 0 && count <= Math.floor((bytes.length - 16) / 8), "Ugyldig rammetabell.");
    check(view.getUint32(12, true) === bytes.length - 16, "EAF-filens lengde stemmer ikke.");
    let sum = 0;
    for (let i = 16; i < bytes.length; i++) sum = (sum + bytes[i]) >>> 0;
    check(sum === view.getUint32(8, true), "EAF-filens kontrollsum stemmer ikke.");
    const frames = [];
    let width, height;
    for (let index = 0; index < count; index++) {
      const size = view.getUint32(16 + index * 8, true);
      const start = 16 + count * 8 + view.getUint32(20 + index * 8, true);
      const end = start + size;
      check(size >= 5 && end <= bytes.length, "Ramme utenfor filen.");
      check(bytes[start] === 90 && bytes[start + 1] === 90, "Ugyldig rammemarkør.");
      const base = start + 2;
      if (bytes[base] === 95 && bytes[base + 1] === 67 && bytes[base + 2] === 0) continue;
      check(size >= 20 && bytes[base] === 95 && bytes[base + 1] === 83 && bytes[base + 2] === 0,
        "Ukjent rammeformat.");
      const bits = bytes[base + 9];
      const w = view.getUint16(base + 10, true), h = view.getUint16(base + 12, true);
      const blocks = view.getUint16(base + 14, true), blockHeight = view.getUint16(base + 16, true);
      check(bits === 8, "Vieweren støtter Puppys 8-bits EAF-filer.");
      check(w > 0 && h > 0 && w <= 1024 && h <= 1024 && blockHeight > 0 && blocks === Math.ceil(h / blockHeight),
        "Ugyldige bildedimensjoner eller blokker.");
      if (width === undefined) { width = w; height = h; }
      check(width === w && height === h, "Rammene har forskjellige dimensjoner.");
      const palette = base + 18 + blocks * 4;
      let cursor = palette + 256 * 4;
      check(cursor <= end, "Ufullstendig fargepalett.");
      const rgba = new Uint8ClampedArray(w * h * 4);
      let pixel = 0;
      for (let block = 0; block < blocks; block++) {
        const length = view.getUint32(base + 18 + block * 4, true);
        const blockEnd = cursor + length;
        check(length >= 1 && blockEnd <= end, "Blokk utenfor rammen.");
        const encoding = bytes[cursor++];
        check(encoding === 0, "Vieweren støtter RLE-koding, som brukes i Puppys originalfiler.");
        check((blockEnd - cursor) % 2 === 0, "Ufullstendig RLE-par.");
        const limit = pixel + w * Math.min(blockHeight, h - block * blockHeight);
        while (cursor < blockEnd) {
          const repeats = bytes[cursor++], color = palette + bytes[cursor++] * 4;
          check(pixel + repeats <= limit, "RLE-data overskrider bildeblokken.");
          // Firmware treats an all-zero BGRA palette entry as transparent;
          // every other palette entry is opaque and converted to RGB565.
          const alpha = bytes[color] || bytes[color + 1] || bytes[color + 2] || bytes[color + 3] ? 255 : 0;
          const r5 = bytes[color + 2] >> 3, g6 = bytes[color + 1] >> 2, b5 = bytes[color] >> 3;
          for (let repeat = 0; repeat < repeats; repeat++, pixel++) {
            rgba[pixel * 4] = (r5 << 3) | (r5 >> 2);
            rgba[pixel * 4 + 1] = (g6 << 2) | (g6 >> 4);
            rgba[pixel * 4 + 2] = (b5 << 3) | (b5 >> 2);
            rgba[pixel * 4 + 3] = alpha;
          }
        }
        check(pixel === limit, "RLE-data fyller ikke bildeblokken.");
      }
      check(cursor === end, "Uventede data etter bildeblokkene.");
      frames.push(rgba);
    }
    check(frames.length > 0, "EAF-filen inneholder ingen bildeframes.");
    return { width, height, frames };
  }
  const codec = { decode };
  if (typeof module !== "undefined" && module.exports) module.exports = codec;
  else root.EafCodec = codec;
})(globalThis);
