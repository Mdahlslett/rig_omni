# Puppy expression viewer

Generate an offline viewer from the original Puppy assets:

```sh
python3 tools/preview_expressions.py
```

Open `build/puppy-viewer.html` in a current browser. The file contains the player
and all registered EAF files, including both Wi-Fi regions and `proud`. It can be copied to another
computer and opened without Python, a server, or an Internet connection.
The generator also produces `build/puppy-viewer.zip`. If an embedded HTML preview
does not allow scripts, download the ZIP, extract it, and open `puppy-viewer.html`
in a normal browser.
The generated HTML also embeds static first-frame previews of all registered assets.
These remain visible when JavaScript is disabled or blocked; successful player
startup hides the fallback gallery.
To open the new animation directly, append `#proud` to the HTML file URL.

`tools/expression_viewer/index.html` also works when served from the repository
by a static HTTP server: it loads the original manifest and EAF files from
`main/boards/puppy/`. Keep that directory available at its repository-relative
path. Opening this source page directly with `file://` shows instructions for
generating the offline file instead of an empty viewer.

The viewer offers expression search, playback/pause, frame stepping/scrubbing,
FPS and loop controls, a circular screen mask, zoom, and PNG frame export.
Playback defaults come from `main/boards/puppy/240_240/emote.json`.

To choose another output path:

```sh
python3 tools/preview_expressions.py --output /tmp/puppy-viewer.html
```

The decoder reuses the EAF layout documented in `tools/analyze_eaf.py` and the
RLE/palette behavior in the installed `esp_emote_gfx` component. It validates
checksums and frame/block bounds, skips `_C` control markers, and supports the
8-bit, RLE-encoded frames used by the current Puppy assets. Other encodings
produce an error rather than a misleading preview. Colors are reduced to RGB565
as in the firmware, then expanded for the browser canvas.

This is an asset preview, not a firmware emulator: it does not run application
events, motor actions, overlays, or hardware display orientation. PNG export
captures the square frame; the circular mask is only a viewing aid. Browser
timing may differ from the device. Regenerate the HTML after changing assets or
their configuration. No firmware, original asset, or package dependency changes
are required.

Decoder checks (requires Node.js, not needed to use or generate the viewer):

```sh
node --test tools/expression_viewer/test_codec.cjs
```
