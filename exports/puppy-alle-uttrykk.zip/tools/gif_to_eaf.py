#!/usr/bin/env python3
"""Convert a 240x240 GIF to the 8-bit RLE EAF used by Puppy (requires Pillow).

FPS and looping belong in the board's emote.json, not in the EAF container.
All source frames, including identical endpoints, are preserved.
"""

import argparse
from itertools import groupby
from pathlib import Path
import struct

from PIL import Image, ImageSequence


def encode_rle(indices: bytes) -> bytes:
    output = bytearray([0])  # EAF encoding 0 = RLE.
    for value, run in groupby(indices):
        count = sum(1 for _ in run)
        while count:
            size = min(count, 255)
            output.extend((size, value))
            count -= size
    return bytes(output)


def convert(source: Path, output: Path) -> int:
    with Image.open(source) as gif:
        if gif.format != "GIF" or gif.size != (240, 240):
            raise ValueError("Input must be a 240x240 GIF; no automatic resizing is performed")
        frames = []
        for frame in ImageSequence.Iterator(gif):
            # Composite optional GIF transparency onto the display background.
            rgba = frame.convert("RGBA")
            background = Image.new("RGBA", rgba.size, (8, 16, 41, 255))
            background.alpha_composite(rgba)
            frames.append(background.convert("RGB"))
    if not frames:
        raise ValueError("Input has no frames")
    colors = set()
    for frame in frames:
        frame_colors = frame.getcolors(maxcolors=256)
        if frame_colors is None:
            colors = None
            break
        colors.update(color for _, color in frame_colors)
        if len(colors) > 256:
            colors = None
            break
    color_indices = None
    if colors is not None:
        ordered = sorted(colors)
        color_indices = {color: index for index, color in enumerate(ordered)}
        rgb = [channel for color in ordered for channel in color]
        palette_image = Image.new("P", (1, 1))
    else:
        sheet = Image.new("RGB", (240, 240 * len(frames)))
        for index, frame in enumerate(frames):
            sheet.paste(frame, (0, index * 240))
        palette_image = sheet.quantize(colors=256, method=Image.Quantize.MEDIANCUT)
        rgb = palette_image.getpalette()
    rgb += [0] * (768 - len(rgb))
    palette_image.putpalette(rgb)
    palette = bytearray()
    for color in range(256):
        r, g, b = rgb[color * 3:color * 3 + 3]
        palette.extend((b, g, r, 255))  # BGRA; black is opaque, not transparent.
    entries, payload = [], bytearray()
    version = b"\0\0\0\0\0\1"  # Same version bytes as existing Puppy assets.
    for frame in frames:
        if color_indices is not None:
            # Pillow's palette lookup can merge nearby colors; preserve exact
            # source colors when the animation already fits an 8-bit palette.
            indices = bytes(color_indices[color] for color in frame.get_flattened_data())
        else:
            indices = frame.quantize(palette=palette_image, dither=Image.Dither.NONE).tobytes()
        blocks = [encode_rle(indices[row * 240:min(row + 32, 240) * 240]) for row in range(0, 240, 32)]
        encoded = (b"ZZ_S\0" + version + bytes([8]) + struct.pack("<HHHH", 240, 240, len(blocks), 32)
                   + b"".join(struct.pack("<I", len(block)) for block in blocks) + palette + b"".join(blocks))
        entries.append((len(encoded), len(payload)))
        payload.extend(encoded)
    # The firmware player uses the final table entry as the end/control marker.
    marker = b"ZZ_C\0" + version
    entries.append((len(marker), len(payload)))
    payload.extend(marker)
    body = b"".join(struct.pack("<II", *entry) for entry in entries) + payload
    header = b"\x89EAF" + struct.pack("<III", len(entries), sum(body) & 0xffffffff, len(body))
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(header + body)
    return len(frames)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    count = convert(args.source, args.output)
    print(f"Created {args.output}: {count} image frames, 240x240, 8-bit palette, RLE")
