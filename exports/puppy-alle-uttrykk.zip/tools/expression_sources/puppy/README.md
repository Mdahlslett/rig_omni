# Puppy: proud

`proud.gif` is the editable animation source for
`main/boards/puppy/emoji/proud.eaf`. It contains 30 240x240 frames and a
one-second repeating animation. The first and last frames match.

The eye artwork is derived from Puppy's existing `confident.eaf`; the hand
symbols are omitted. The eyes lift and gently widen to suggest friendly pride.
The source is stored outside the firmware asset directory to avoid accidentally
packing the GIF into the device's asset partition.

Regenerate the EAF from the repository root (Python with Pillow installed):

```sh
python3 tools/gif_to_eaf.py tools/expression_sources/puppy/proud.gif main/boards/puppy/emoji/proud.eaf
python3 tools/preview_expressions.py
```

Open `build/puppy-viewer.html` and select `proud`. The manifest configures
30 FPS and looping. Build/flash a Puppy firmware package including the updated
assets partition when testing on the physical robot; application-only flashing
will not install the new animation.

The firmware can select it with `SetEmotion("proud")`, or receive
`{"type":"llm","emotion":"proud"}` from the conversation server. The server
still needs to be configured to send that name; registering a local asset does
not automatically change the LLM's emotion vocabulary. No automatic conversation
trigger or changes to other robot boards are included.
