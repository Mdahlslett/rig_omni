#!/usr/bin/env python3
"""Build a self-contained, offline Puppy expression viewer (Python stdlib only)."""

import argparse
import base64
import html
import json
import struct
import zipfile
import zlib
from pathlib import Path

from analyze_eaf import parse_file


def first_frame_png(path: Path) -> bytes:
    """Static fallback when an HTML preview blocks JavaScript (stdlib only)."""
    data, entries, parsed = parse_file(str(path))
    _, offset = entries[0]
    info = parsed[0][2]
    width, height = info["width"], info["height"]
    if info["bit_depth"] != 8:
        raise ValueError(f"Unsupported preview bit depth: {path}")
    base = 16 + len(entries) * 8 + offset + 2
    palette = base + 18 + info["blocks"] * 4
    cursor = palette + 1024
    indices = bytearray()
    for block in range(info["blocks"]):
        length = struct.unpack_from("<I", data, base + 18 + block * 4)[0]
        end = cursor + length
        if data[cursor] != 0 or (length - 1) % 2:
            raise ValueError(f"Unsupported preview encoding: {path}")
        cursor += 1
        while cursor < end:
            indices.extend(bytes([data[cursor + 1]]) * data[cursor])
            cursor += 2
    if len(indices) != width * height:
        raise ValueError(f"Invalid preview pixel count: {path}")
    colors = []
    for color in range(256):
        b, g, r, a = data[palette + color * 4:palette + color * 4 + 4]
        r5, g6, b5 = r >> 3, g >> 2, b >> 3
        colors.append(bytes([(r5 << 3) | (r5 >> 2), (g6 << 2) | (g6 >> 4),
                             (b5 << 3) | (b5 >> 2), 255 if r or g or b or a else 0]))
    pixels = b"".join(colors[color] for color in indices)
    rows = b"".join(b"\0" + pixels[row * width * 4:(row + 1) * width * 4] for row in range(height))

    def chunk(kind, content):
        return struct.pack(">I", len(content)) + kind + content + struct.pack(">I", zlib.crc32(kind + content))

    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(rows)) + chunk(b"IEND", b""))


def build_viewer(output: Path) -> None:
    tools = Path(__file__).resolve().parent
    board = tools.parent / "main/boards/puppy"
    expressions = json.loads((board / "240_240/emote.json").read_text())
    items = []
    previews = []
    for expression in expressions:
        regions = ("domestic", "overseas") if expression["emote"] == "wificonfig" else (None,)
        for region in regions:
            filename = f"wificonfig_{region}.eaf" if region else expression["src"]
            items.append({
                "name": expression["emote"],
                "region": region,
                "file": filename,
                "fps": expression["fps"],
                "loop": expression["loop"],
                "data": base64.b64encode((board / "emoji" / filename).read_bytes()).decode("ascii"),
            })
            image = base64.b64encode(first_frame_png(board / "emoji" / filename)).decode("ascii")
            label = expression["emote"] + (f" · {region}" if region else "")
            previews.append(f'<figure><img src="data:image/png;base64,{image}" alt="{html.escape(label)}" '
                            f'width="240" height="240"><figcaption>{html.escape(label)}</figcaption></figure>')
    viewer = tools / "expression_viewer"
    page = (viewer / "index.html").read_text()
    page = page.replace('<script src="codec.js"></script>', '<script>' + (viewer / "codec.js").read_text() + '</script>')
    page = page.replace('<script src="app.js"></script>', '<script>' + (viewer / "app.js").read_text() + '</script>')
    # Escape '<' so embedded data cannot terminate the script element.
    page = page.replace('<script id="expression-data" type="application/json">[]</script>',
                        '<script id="expression-data" type="application/json">' + json.dumps(items).replace("<", "\\u003c") + '</script>')
    gallery = (f'<details id="static-gallery" open><summary>Se alle {len(items)} uttrykk som bilder</summary>'
               '<p>Hvis forhåndsvisningen blokkerer animasjonene, kan du fortsatt se uttrykkene her. '
               'For avspilling: last ned ZIP-filen, pakk den ut og åpne puppy-viewer.html i nettleseren på PC.</p>'
               '<div class="gallery">' + "".join(previews) + '</div></details>')
    page = page.replace("<!-- EMBED_PREVIEWS -->", gallery)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(page, encoding="utf-8")
    archive = output.with_suffix(".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
        bundle.writestr("puppy-viewer.html", page)
    print(f"Created {output.resolve()} ({len(items)} expressions including both Wi-Fi regions)")
    print("Open the HTML file in a browser. No server or Internet connection is needed.")
    print(f"Download alternative: {archive.resolve()} (unzip and open puppy-viewer.html)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parents[1] / "build/puppy-viewer.html")
    build_viewer(parser.parse_args().output)
