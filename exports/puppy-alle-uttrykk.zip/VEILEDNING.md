# Puppy-uttrykk: forklaring og veiledning for en annen AI

## Hva ZIP-filen inneholder

- `puppy-viewer.html`: ferdig viewer. Pakk ut ZIP-filen og åpne HTML-filen i en vanlig nettleser. Velg et uttrykk i listen.
- `main/boards/puppy/emoji/*.eaf`: 30 animasjonsfiler, inkludert `proud` og begge Wi-Fi-variantene.
- `main/boards/puppy/240_240/emote.json`: kobling mellom navn, fil, FPS og looping.
- `main/boards/puppy/240_240/layout.json`: skjermoppsett.
- `tools/expression_sources/puppy/proud.gif`: redigerbar GIF-kilde for `proud`.
- `tools/gif_to_eaf.py`: konverterer en GIF til 8-bits RLE-EAF.
- `tools/preview_expressions.py`, `tools/analyze_eaf.py` og `tools/expression_viewer/`: generering, analyse og kildekode for vieweren.

Mappestrukturen tilsvarer repositoryet. Ressurspakken er ikke hele firmwareprosjektet eller ESP-IDF-verktøykjeden. Konvertering og viewergenerering kan likevel kjøres i den utpakkede pakken. Firmwarebygging krever hele prosjektet og ESP-IDF.

## Slik brukes animasjonene

Programvaren velger et navn, for eksempel `happy`. EmoteDisplay slår opp navnet i ressurspakken, finner `happy.eaf` og spiller den av med FPS og looping fra emote.json. Ved bygging pakkes filene til `board_assets.bin`, som flashes til robotens `assets`-partisjon.

Eksempel:

```json
{"emote": "proud", "src": "proud.eaf", "loop": true, "fps": 30}
```

Under samtaler setter roboten selv blant annet `listen`, `thinking` og `neutral`. Samtaletjenesten kan sende:

```json
{"type": "llm", "emotion": "proud"}
```

Firmware kan allerede motta et nytt uttrykksnavn uten en ny hardkodet if-setning. Men serveren/LLM-oppsettet må kjenne navnet og sende det. Å legge til en EAF-fil endrer ikke automatisk LLM-ens oppførsel. Serveroppsettet er ikke inkludert i dette repositoryet. En ny robottilstand kan erstatte uttrykket som spilles.

## Krav og anbefalinger

| Egenskap | Hva du skal bruke |
|---|---|
| Bildestørrelse | Nøyaktig 240 × 240 piksler. Ikke skaler eller beskjær utilsiktet. |
| Arbeidsformat | GIF, eller nummererte PNG-bilder som senere settes sammen til GIF. Bare proud har GIF-kilde i pakken; de eldre originalene finnes her som EAF. |
| Robotformat | Binær EAF. Det hjelper ikke å endre filendelsen fra GIF til EAF. |
| Koding | Bruk 8-bits fargepalett og RLE for å passe både eksisterende Puppy-ressurser og vår viewer. |
| Farger | Maksimalt 256 farger etter konvertering; bruk gjerne betydelig færre og samme palett gjennom hele animasjonen. Skjermen bruker RGB565, så små fargenyanser kan gå tapt. |
| Tempo | Normalt 30 FPS. Tempoet bestemmes av emote.json. Konvertereren overfører ikke individuelle GIF-bildetider til EAF. |
| Loop | Bruk loop=true for vedvarende uttrykk. Overgangen fra siste til første bilde må være jevn. Identiske endepunkter er nyttig, men ikke et formatkrav. |
| Varighet | For eksempel 30 bildeframes ved 30 FPS, omtrent ett sekund. Alle uttrykk trenger ikke ha samme lengde. |
| Skjermform | Filen er kvadratisk, men skjermen er rund. Hold viktige detaljer innenfor sirkelen. |
| Stil | Bruk eksisterende øyne, plassering og bakgrunn som referanse. proud bruker en mørk bakgrunn med RGB (8, 16, 41). Dette er en stilreferanse, ikke et universelt formatkrav. |
| Gjennomsiktighet | Foretrekk en ferdig, ugjennomsiktig bakgrunn. Vår konverterer legger gjennomsiktige områder over RGB (8, 16, 41). |
| Detaljer | Store, tydelige former og rolige bevegelser fungerer best. Mye støy, dithering og gradienter gir større filer og dårligere RLE-komprimering. |
| Orientering | Ikke speil eller roter ressursene for å kompensere for driverinnstillinger uten en fysisk test. Vieweren emulerer ikke skjermdriverens orientering. |

Viktige unntak i eksisterende konfigurasjon: nvs_reset bruker 5 FPS uten looping. wificonfig bruker 1 FPS og looping. Ikke sett alle uttrykk til 30 FPS ukritisk.

GIF lagrer tid i hundredels sekunder og kan ikke angi nøyaktig 33,333 ms per bilde. proud.gif bruker 30/30/40 ms-intervaller og 30 bilder totalt. EAF-avspilleren bruker i stedet den faste bildefrekvensen fra emote.json. Noen GIF-eksportører slår sammen identiske bilder; kontroller faktisk antall eksporterte bilder før konvertering.

## Endre et eksisterende uttrykk

1. Behold en sikker kopi. La den andre AI-en lage en ny arbeidsfil før originalen eventuelt erstattes.
2. Behold uttrykksnavnet og filnavnet dersom målet er å endre utseendet uten å endre samtaletjenesten. En ny happy.eaf vises der programvaren allerede velger happy.
3. Endre bare Puppy-ressursen. Arm, Hover og TARS har egne mapper selv om mange eksisterende filer er like.
4. Ikke endre felles avspillingskode, skjermdriver, GPIO-er, partisjonstabell eller andre roboters filer for en ren animasjonsendring.

## Legg til et nytt uttrykk

1. Lagre kilden utenfor firmwaremappen, for eksempel `tools/expression_sources/puppy/curious.gif`.
2. Konverter til `main/boards/puppy/emoji/curious.eaf`.
3. Legg til ett unikt navn i `main/boards/puppy/240_240/emote.json`:

```json
{"emote": "curious", "src": "curious.eaf", "loop": true, "fps": 30}
```

4. Bruk korte, entydige navn med små bokstaver, gjerne understrek. Navnene må stemme nøyaktig mellom servermelding og manifest. Ikke legg til ekstra JSON-komma på slutten av listen.
5. Konfigurer serveren til å sende det nye navnet når det skal brukes i samtalen. Hvis serveren ikke kan endres, vurder å erstatte grafikken bak et eksisterende navn i stedet.

Behold wificonfig_domestic.eaf og wificonfig_overseas.eaf og QR-innholdet deres. wificonfig.eaf er et generert navn valgt under bygging. Ikke erstatt disse med en vanlig ansiktsanimasjon.

## Konvertering og kontroll

Kjør kommandoene fra prosjektroten/roten av den utpakkede pakken. Konvertereren krever Pillow; den er testet med Pillow 13.0.0. Bruk helst et aktivert Python-virtuelt miljø:

```sh
python3 -m pip install 'Pillow==13.0.0'
python3 tools/gif_to_eaf.py tools/expression_sources/puppy/proud.gif main/boards/puppy/emoji/proud.eaf
python3 tools/preview_expressions.py
```

Vieweren krever ingen Python-pakker under generering og ingen nettforbindelse under bruk. Den nygenererte filen er `build/puppy-viewer.html`, med en nedlastbar ZIP ved siden av. Den ferdige viewerfilen er et øyeblikksbilde og oppdateres ikke automatisk når en EAF-fil endres.

Vieweren viser 8-bits RLE-EAF og er et verktøy for ressurskontroll, ikke en emulator for samtaletilstander, skjermoverlegg, motorer eller maskinvare.

Analyser en fil:

```sh
python3 tools/analyze_eaf.py main/boards/puppy/emoji/proud.eaf
```

EAF-tabellen har også en avsluttende _C-kontrollmarkør. Denne er ikke et synlig bilde. Dermed kan tabellens antall være én høyere enn antallet bildeframes. Analyseverktøyets non-_S frame-melding for akkurat denne markøren er forventet. Ikke fjern markøren eller endre kontrollsummer manuelt; bruk konvertereren.

Hvis Node.js er tilgjengelig, kontroller dekoderen og alle EAF-ressursene:

```sh
node --test tools/expression_viewer/test_codec.cjs
```

Sjekk i vieweren at navnet finnes, at bildet ikke er svart, at tempo og loop er riktige, og at siste/første overgang er jevn. Kontroller faktisk bildeantall og format. Ved en planlagt endring i proud må tester som bevisst forventer 30 bilder og like endepunkter vurderes opp mot de nye kravene; ikke slå av testene for å skjule en konverteringsfeil.

## Prøving på robot

I hele firmwareprosjektet: aktiver ESP-IDF 5.5.3 og bygg Puppy for esp32s3 i eget byggområde, med riktig region og Puppy valgt i sdkconfig. Vi har brukt:

```sh
idf.py -B build/puppy -DIDF_TARGET=esp32s3 reconfigure
ninja -C build/puppy -j4
```

Eksisterende sdkconfig kan overstyre standardkortet; bekreft CONFIG_BOARD_TYPE_PUPPY=y før bygging. Kontroller at den nye ressursen er registrert i den genererte index.json, inkludert i board_assets.bin, og at ressurspakken passer i assets-partisjonen. Ikke endre partisjonstabellen for å skjule en for stor animasjon; reduser heller bilder, detaljer eller farger når det passer formålet.

Flash med prosjektets IDF-arbeidsflyt og riktig fysisk serieport, og inkluder assets-partisjonen. Kun application-only-flashing installerer ikke den nye EAF-filen. Ikke bruk erase-flash som et rutinemessig animasjonstrinn; det kan slette lagrede innstillinger. Ta hensyn til robotens faktiske maskinvare og eksisterende konfigurasjon.

proud er bygget og kontrollert i ressurspakken og vieweren. Den er ennå ikke verifisert på fysisk robot. Vi har ikke endret produsentens samtaletjeneste til automatisk å sende proud.

## Prompt du kan gi en annen AI

```text
Du skal hjelpe meg å redigere eller lage et ansiktsuttrykk for RIG-Puppy.
Bruk de vedlagte eksisterende animasjonene som stilreferanse. Les VEILEDNING.md
og repositoryets CLAUDE.md/AGENTS.md hvis de finnes før du gjør endringer.

Oppgaven er: [beskriv uttrykket og ønsket bevegelse].
Uttrykksnavn: [f.eks. curious].
Type endring: [nytt uttrykk / erstatt eksisterende navn].

Lever en arbeidsfil på nøyaktig 240x240 piksler. Bruk få, stabile farger,
tydelige former og ingen utilsiktede nye ansiktsdeler. Hold viktig innhold
innenfor den runde skjermen. Unngå kamerabevegelse og uønsket skalering.
Ønsket avspilling: [f.eks. 30 bildeframes ved 30 FPS, sømløs loop].

Lagre redigerbar GIF/PNG-kilde utenfor main/boards/puppy/emoji.
Bruk tools/gif_to_eaf.py til å produsere 8-bits RLE-EAF; ikke bare bytt
filendelse og ikke konstruer kontrollsummer manuelt.
Ved et nytt navn: legg til én post i Puppys emote.json med src, fps og loop.
Ved erstatning: behold det eksisterende navnet og vurder opprinnelig tempo.

Ikke endre andre roboters ressurser, felles firmware, GPIO-er eller
partisjonstabell for å få en animasjon til å fungere. Bevar annet lokalt arbeid.
Ikke overskriv Wi-Fi-QR-ressurser. Ikke endre serveroppsett uten eksplisitt beskjed.

Generer vieweren på nytt. Kontroller bildeantall, dimensjoner, farger,
kontrollsum, avspilling og loop. Kjør relevante eksisterende dekodertester.
Hvis hele firmwaremiljøet er tilgjengelig, bygg Puppy og bekreft at ressursen
er med i board_assets.bin og passer i assets-partisjonen.

Oppgi nøyaktig hvilke filer du endret, hvordan det ble testet, og hva som
gjenstår på fysisk robot. Skill mellom fungerende lokal avspilling og
LLM-integrasjon: et nytt uttrykksnavn må også kunne sendes av samtaleserveren.
```
